"""NeuroML — Advanced Neuron-Geared Clash Royale Player (v10: Dueling Double DQN + PER + N-Step + Full Vision + Groq VLM).

Architecture acts like a biological brain with cortical & limbic pathways:
  1. Sensory Cortex (38 input neurons -> 128 LayerNorm + SiLU neurons)
  2. Residual Synaptic Blocks (2 x 128-neuron skip-connected cortical columns
     with LayerNorm & SiLU gating so gradients never vanish)
  3. Dueling Limbic Pathways (Wang et al.):
     - State-Value Stream V(s) (64 limbic neurons -> 1 baseline dopamine prediction)
     - Action-Advantage Stream A(s,a) (64 motor neurons -> 20 card x zone advantages)
     - Combined via Q(s,a) = V(s) + (A(s,a) - mean(A(s,*)))
  4. Double DQN Target Decoupling (van Hasselt et al.):
     - Online policy selects best next action a* = argmax_a Q_policy(s', a)
     - Target network evaluates Q_target(s', a*) to eliminate Q-value overestimation
  5. Prioritized Experience Replay (PER, Schaul et al.):
     - Transitions with high TD-error |delta| (especially surprise tower-damage
       punishments and big wins) are replayed with higher probability P(i) ~ |delta_i|^alpha
       and weighted with importance-sampling weights w_i = (N * P(i))^(-beta)
  6. 3-Step Bootstrapping (N-Step Returns):
     - Propagates delayed tower-damage punishments and push rewards 3x faster
       back to the card placement that caused them
  7. Polyak Soft Target Synaptic Plasticity:
     - Smoothly blends target weights every training step: theta_target <- tau*theta_policy + (1-tau)*theta_target

Full Vision & Live Groq VLM (`qwen/qwen3.8-27b`):
  - Pixel-level HP bar scanner tracks all 5 towers (ally_left, ally_right,
    ally_king, enemy_left, enemy_right) + active battlefield unit health bars +
    individual card slot pink elixir badges.
  - Live Groq VLM (`qwen/qwen3.8-27b`) classifies unknown screens AND acts as the
    visual + tactical Damage Judge to sentence the surge neurons with immediate
    negative punishment (-0.50 to -3.50, zero positive dopamine) whenever our
    towers take damage.
"""
import base64
import io
import itertools
import json
import math
import os
import random
import re
import subprocess
import threading
import time
import urllib.request
from collections import deque

import torch
import torch.nn as nn
import torch.optim as optim

import sys
sys.stdout.reconfigure(encoding="utf-8", errors="replace")

CFG = json.load(open("bot_config.json"))
DEV = CFG["device"]
SHOT_DIR = "cr_bot"
os.makedirs(SHOT_DIR, exist_ok=True)
LOG = open("bot.log", "a", buffering=1, encoding="utf-8", errors="replace")
CARDS_DB = json.load(open("cards.json"))

STATE_DIM = 38
ACTION_DIM = 20
CARD_VOCAB = 16

TICK_SECONDS = 2.2  # fast play (was 3.2s; snappy but still human-possible)
SWIPE_START_JITTER = 6  # pixels of humanization jitter on card swipes


def log(msg):
    line = f"[{time.strftime('%H:%M:%S')}] {msg}"
    LOG.write(line + "\n")
    print(line, flush=True)


GROQ_UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36 NeuroML/11.5"
import urllib.error


def sh(args, timeout=25):
    return subprocess.run(
        ["adb", "-s", DEV] + args, capture_output=True, timeout=timeout
    )


_shot_thread = [None]
_shot_result = [None]


def screenshot_async():
    """Pipeline: start the phone-side screencap in a background thread NOW; the
    main loop keeps playing/acting while the (slow ~3s) PNG encode happens."""
    def _work():
        try:
            _shot_result[0] = sh(["exec-out", "screencap", "-p"], timeout=15)
        except Exception as e:
            _shot_result[0] = None
    _shot_thread[0] = threading.Thread(target=_work, daemon=True)
    _shot_thread[0].start()


def screenshot():
    """If an async shot was started, wait for it (<3s); else take a sync one."""
    out = os.path.join(SHOT_DIR, "latest.png")
    th = _shot_thread[0]
    if th is not None:
        th.join(timeout=15)
        _shot_thread[0] = None
        res = _shot_result[0]
        if res is not None and len(res.stdout) > 1000:
            with open(out, "wb") as f:
                f.write(res.stdout)
            return out
    result = sh(["exec-out", "screencap", "-p"], timeout=15)
    with open(out, "wb") as f:
        f.write(result.stdout)
    return out


def tap(x, y):
    sh(["shell", "input", "tap", str(x), str(y)])
    time.sleep(0.4)


# ---------------------- Groq VLM API (Vision + Damage Judge) ----------------------
GROQ_VISION_MODEL = "qwen/qwen3.8-27b"
GROQ_TEXT_MODEL = "qwen/qwen3.8-27b"

# Global Groq rate-limit gate: when a 429/rate-limit error hits, silence ALL Groq
# calls (vision, damage judge, mentor, VLM fallback) for this many seconds.
_groq_muted_until = [0.0]
GROQ_MUTE_SECONDS = 45


def groq_is_muted():
    return time.time() < _groq_muted_until[0]


def mute_groq(seconds=None):
    _groq_muted_until[0] = max(_groq_muted_until[0], time.time() + (seconds or GROQ_MUTE_SECONDS))


def load_groq_key():
    """Load Groq API key from GROQ_API_KEY env var or groq_key.txt on disk."""
    k = os.environ.get("GROQ_API_KEY", "").strip()
    if k:
        return k
    if os.path.exists("groq_key.txt"):
        try:
            return open("groq_key.txt").read().strip()
        except Exception:
            return ""
    return ""


def groq_vision_classify(img):
    """Full-vision multimodal screen classifier using Groq's qwen/qwen3.8-27b VLM
    when the fast pixel probe returns 'unknown'."""
    key = load_groq_key()
    if not key:
        return "unknown"
    try:
        thumb = img.copy()
        thumb.thumbnail((384, 832))
        buf = io.BytesIO()
        thumb.save(buf, format="JPEG", quality=68)
        b64 = base64.b64encode(buf.getvalue()).decode()
        payload = {
            "model": GROQ_VISION_MODEL,
            "messages": [{
                "role": "user",
                "content": [
                    {
                        "type": "text",
                        "text": (
                            "Classify this Clash Royale screen into EXACTLY one word from: "
                            "battle, lobby, result, quit_dialog, popup, unknown. Do not explain."
                        ),
                    },
                    {"type": "image_url", "image_url": {"url": f"data:image/jpeg;base64,{b64}"}},
                ],
            }],
            "max_tokens": 16,
            "temperature": 0.0,
        }
        payload = {
            "model": GROQ_VISION_MODEL,
            "messages": [{
                "role": "user",
                "content": [
                    {
                        "type": "text",
                        "text": (
                            "Classify this Clash Royale screen into EXACTLY one word from: "
                            "battle, lobby, result, quit_dialog, popup, unknown. Do not explain."
                        ),
                    },
                    {"type": "image_url", "image_url": {"url": f"data:image/jpeg;base64,{b64}"}},
                ],
            }],
            "max_tokens": 16,
            "temperature": 0.0,
        }
        req = urllib.request.Request(
            "https://api.groq.com/openai/v1/chat/completions",
            data=json.dumps(payload).encode(),
            headers={
                "Authorization": f"Bearer {key}",
                "Content-Type": "application/json",
                "User-Agent": GROQ_UA,
            },
        )
        with urllib.request.urlopen(req, timeout=6) as resp:
            data = json.loads(resp.read().decode())
            ans = (data["choices"][0]["message"].get("content") or "").strip().lower()
            for label in ("battle", "lobby", "result", "quit_dialog", "popup"):
                if label in ans:
                    log(f"groq VLM classified unknown screen -> {label}")
                    return label
    except urllib.error.HTTPError as e:
        body = ""
        try:
            body = e.read().decode(errors="ignore")
        except Exception:
            pass
        if e.code in (429, 403) or "Rate limit" in body:
            mute_groq()
            log(f"groq rate-limited — muting all Groq calls for {GROQ_MUTE_SECONDS}s")
        else:
            log(f"groq vision note: HTTP {e.code} {body[:80]}")
    except Exception as e:
        log(f"groq vision note: {str(e)[:90]}")
    return "unknown"


def _any(img, tests=None):
    return None  # removed placeholder


def groq_damage_punishment(dmg_info, img=None):
    """Calculate severe negative dopamine punishment when our towers take damage.
    Queries Groq's qwen/qwen3.8-27b VLM (with visual snapshot when available)
    and combines with proportional HP-drop physics so the surge neurons are
    strictly punished whenever our towers take damage."""
    hp_drop = dmg_info.get("ally_hp_drop", 0.0)
    towers_lost = dmg_info.get("ally_towers_lost", 0)
    base_punish = -max(0.50, round(hp_drop * 4.0 + towers_lost * 1.6, 2))
    base_punish = max(-3.5, base_punish)

    if groq_is_muted():
        return base_punish, "groq_muted_local_fallback"
    key = load_groq_key()
    if not key:
        return base_punish, "local_sensor"

    try:
        prompt = (
            f"Clash Royale RL Judge: Our friendly towers just took damage! "
            f"HP fraction lost={hp_drop:.3f}, towers collapsed={towers_lost}, "
            f"left_hp={dmg_info.get('ally_left', 0):.2f}, right_hp={dmg_info.get('ally_right', 0):.2f}, "
            f"king_hp={dmg_info.get('ally_king', 0):.2f}. "
            f"Output ONLY a single negative float between -0.50 and -3.50 (more negative for bigger damage or collapsed tower) to punish the surge neurons."
        )
        if img is not None:
            thumb = img.copy()
            thumb.thumbnail((320, 690))
            buf = io.BytesIO()
            thumb.save(buf, format="JPEG", quality=60)
            b64 = base64.b64encode(buf.getvalue()).decode()
            content = [
                {"type": "text", "text": prompt},
                {"type": "image_url", "image_url": {"url": f"data:image/jpeg;base64,{b64}"}},
            ]
        else:
            content = prompt

        payload = {
            "model": GROQ_VISION_MODEL,
            "messages": [{"role": "user", "content": content}],
            "max_tokens": 16,
            "temperature": 0.0,
        }
        req = urllib.request.Request(
            "https://api.groq.com/openai/v1/chat/completions",
            data=json.dumps(payload).encode(),
            headers={
                "Authorization": f"Bearer {key}",
                "Content-Type": "application/json",
                "User-Agent": GROQ_UA,
            },
        )
        with urllib.request.urlopen(req, timeout=7) as resp:
            data = json.loads(resp.read().decode())
            txt = (data["choices"][0]["message"].get("content") or "").strip()
            m = re.search(r"-[0-9]+(?:\.[0-9]+)?", txt)
            if m:
                val = float(m.group(0))
                # Ensure severe damage / lost tower is never under-punished
                val = min(val, base_punish * 0.85)
                val = max(-3.5, min(-0.45, round(val, 2)))
                return val, "groq_vlm_judge"
    except Exception as e:
        err = e.read().decode(errors="ignore")[:90] if hasattr(e, "read") else str(e)[:90]
        log(f"groq damage judge fallback to local punishment ({base_punish:+.2f}): {err}")
    return base_punish, "groq_key_local_fallback"


# ---------------------- Groq OSS AI Coach: Punisher + Mentor ----------------------
GROQ_COACH_MODEL = "openai/gpt-oss-120b"
SPOT_TO_ACTION = {}  # populated after SPOT_NAMES is defined (see below)


def groq_deck_builder(player_deck=None):
    """Groq deck-builder: fetch the real meta (from meta_decks.json, refreshed
    via web) and ask gpt-oss-120b to evaluate + redesign the deck the bot uses.
    Returns {'deck': [...8 card names...], 'critique': str, 'source': str}.
    Only *suggests* decks; actual deck changes must be made manually in-game
    (bot never opens Deck Edit to avoid touching account settings).
    """
    meta = {}
    try:
        meta = json.load(open("meta_decks.json"))
    except Exception:
        return {"deck": None, "critique": "no meta data", "source": "local"}
    key = load_groq_key()
    if not key:
        return {"deck": None, "critique": "no key", "source": "local"}
    import re as _re
    # Deck architect learns from the agent's own game memory: which placements won/lost
    try:
        _gm = game_memory_digest()
        _gm_line = _gm.get("one_line", "")
        _gm_best = _gm.get("best_spots") or []
    except Exception:
        _gm_line, _gm_best = "", []
    prompt = (
        "You are the NeuroML Deck Architect for a Clash Royale RL agent. "
        f"Current ladder meta decks (fetched {meta.get('fetched_at')}):\n"
        + json.dumps(meta.get("top_meta_decks", [])[:6], indent=1)
        + f"\n\nAgent's current deck: {player_deck or 'unknown (use meta consensus)'}\n"
        + f"\nAgent's game memory (how it plays): {_gm_line or 'no history yet'}\n"
        + (f"Placements that historically paid best: {_gm_best}\n" if _gm_best else "")
        + "1) Compare the agent's deck to the meta and name the biggest weaknesses CONSTRAINED by how this agent plays.\n"
        + "2) Output the strongest 8-card deck possible given the meta AND this agent's proven play style.\n\n"
        + 'Reply ONLY with minified JSON, no markdown, no reasoning: '
        + '{"best_deck": ["card1", "card2", "card3", "card4", "card5", "card6", "card7", "card8"], '
        + '"why": "<25 words>"}\n\n'
        + "Important: Start your reply with the opening { character immediately."
    )
    try:
        payload = {"model": GROQ_COACH_MODEL,
                   "messages": [{"role": "user", "content": prompt}],
                   "max_tokens": 900, "temperature": 0.0,
                   "reasoning_effort": "low"}
        req = urllib.request.Request(
            "https://api.groq.com/openai/v1/chat/completions",
            data=json.dumps(payload).encode(),
            headers={"Authorization": f"Bearer {key}", "Content-Type": "application/json",
                     "User-Agent": GROQ_UA, "Accept": "application/json"})
        with urllib.request.urlopen(req, timeout=14) as resp:
            data = json.loads(resp.read().decode())
            txt = (data["choices"][0]["message"].get("content") or "").strip()
            m = _re.search(r"\{[^{}]*\}", txt, _re.S)
            if not m:
                return {"deck": None, "critique": "no json", "source": "groq"}
            j = json.loads(m.group(0))
            deck = j.get("best_deck")
            if isinstance(deck, list) and len(deck) >= 6:
                return {"deck": [str(c) for c in deck[:8]],
                        "critique": str(j.get("why", ""))[:200], "source": "groq_deck_architect"}
            return {"deck": None, "critique": "bad deck shape", "source": "groq"}
    except Exception as e:
        err = e.read().decode(errors="ignore")[:80] if hasattr(e, "read") else str(e)[:80]
        return {"deck": None, "critique": f"architect unavailable: {err}", "source": "groq_unavailable"}


def groq_reward_governor(state_desc, played_spot, prev_reward, img=None):
    """GROQ IS THE REWARD GOVERNOR ON EVERY TICK: it gets the FULL CONTEXT
    (elixir, towers, HP-mass, lane threats, desperation, hand, opponent pushes,
    pain channels, game memory) and decides the final dopamine with that
    context — fixing flat shaped rewards that punish e.g. casts that look bad
    but were NECESSARY at low tower HP (desperation rocket on a cheap barrel).
    Returns dict: {agree, reward_delta, recommended_spot, critique, source}
    """
    out = {"agree": None, "reward_delta": None, "recommended_spot": None,
           "critique": None, "source": None}
    if groq_is_muted():
        return out
    key = load_groq_key()
    if not key:
        return out
    try:
        import re as _re
        # The coach knows the agent's GAME MEMORY — past performance shapes its advice
        try:
            gm = game_memory_digest()
            gmline = gm.get("one_line", "")
            best = gm.get("best_spots") or []
            avoid = gm.get("avoid_spots") or []
        except Exception:
            gmline, best, avoid = "", [], []
        prompt = (
            "You are NeuroML's REWARD GOVERNOR for a Clash Royale RL agent."
            " You judge every single play with FULL CONTEXT and assign the final dopamine.\n"
            f"Agent's game memory: {gmline or 'no history yet (first games)'}\n"
            + (f"Spots that historically paid best: {best}\nSpots that historically lost dopamine: {avoid}\n" if best or avoid else "")
            + f"FULL CONTEXT: {state_desc}\n"
            + f"The agent just played: {played_spot}\n"
            + f"Local shaped reward was: {prev_reward:+.2f}\n\n"
            + "Reply ONLY with minified JSON, no markdown, no reasoning. Start your reply with { immediately.\n"
            + '{"reward_delta": <float -2.5..+1.5>, "recommended_spot": <one of bridge_left|bridge_right|left_defend|right_defend|center_back>, "critique": "<max 22 words>"}\n\n'
            + "JUDGMENT PRINCIPLES:\n"
            + "- Desperation is allowed: at low king-HP or against a pushed-away tower,"
            + " expensive spells at cheap troops CAN be correct — judge by necessity, not by elixir math alone.\n"
            + "- Punish wasting elixir on nothing (hits empty lane, overdefense of a single cheap troop).\n"
            + "- Reward counter-pushes (attacking the lane the enemy did NOT commit to).\n"
            + "- Reward targeting the LOWER-HP enemy tower for finishing pressure.\n"
            + "- Reward kiting: cheap troops placed center to drag heavy attackers away.\n"
            + "- DO NOT punish cheap-card cycling when up on elixir and no threat.\n\n"
            + "You MUST judge differently when the context changes — an identical play can be genius"
            + " at 1 tower HP or terrible at full towers.\n"
        )
        content = prompt
        # gpt-oss-120b text-only: the structured state_desc already carries full vision
        if img is not None:
            pass  # image kept for future multimodal coach; text-only avoids API rejection
        payload = {
            "model": GROQ_COACH_MODEL,
            "messages": [{"role": "user", "content": content}],
            "max_tokens": 512,  # gpt-oss reasoning tokens consume budget; keep JSON in decoded output
            "temperature": 0.0,
        }
        req = urllib.request.Request(
            "https://api.groq.com/openai/v1/chat/completions",
            data=json.dumps(payload).encode(),
            headers={"Authorization": f"Bearer {key}", "Content-Type": "application/json",
                     "User-Agent": GROQ_UA, "Accept": "application/json"},
        )
        with urllib.request.urlopen(req, timeout=14) as resp:
            data = json.loads(resp.read().decode())
            txt = (data["choices"][0]["message"].get("content") or "").strip()
            m = _re.search(r"\{[^{}]*\}", txt, _re.S)
            if not m:
                return out
            j = json.loads(m.group(0))
            rd = j.get("reward_delta")
            if isinstance(rd, (int, float)):
                out["reward_delta"] = max(-1.5, min(0.5, float(rd)))
            rs = j.get("recommended_spot")
            if rs in SPOT_TO_ACTION:
                out["recommended_spot"] = rs
            cr = j.get("critique")
            if isinstance(cr, str):
                out["critique"] = cr.strip()[:160]
            out["source"] = "groq_oss_coach"
            _metrics["mentor_reviews"] = _metrics.get("mentor_reviews", 0) + 1
    except Exception as e:
        err = e.read().decode(errors="ignore")[:80] if hasattr(e, "read") else str(e)[:80]
        out["critique"] = f"coach unavailable: {err}"
        out["source"] = "groq_oss_coach_unavailable"
    return out


def mentor_log_line(entry):
    """Append one coach review to the machine-readable coach feed + human log."""
    try:
        ts = time.strftime("%H:%M:%S")
        entry["t"] = ts
        with open(COACH_FILE, "a") as f:
            f.write(json.dumps(entry) + "\n")
        MENTOR_LOG.write(
            f"[{ts}] played={entry.get('played')} critique={entry.get('critique')} "
            f"delta={entry.get('reward_delta')} recommend={entry.get('recommended_spot')} agree={entry.get('agree')}\n"
        )
    except Exception:
        pass


# ---------------------- Full Vision / Sensing ----------------------
ELIXIR_X0 = 228
ELIXIR_X1 = 948


def elixir_count(img):
    """Measure the horizontal elixir bar fill at y=2292..2312 (below card cost badges)."""
    best = 0.0
    for y in range(2292, 2314, 3):
        right = ELIXIR_X0
        for x in range(ELIXIR_X0, ELIXIR_X1, 4):
            r, g, b = img.getpixel((x, y))
            if r > 150 and g < 95 and b > 150:
                right = x
        fill = (right - ELIXIR_X0) / float(ELIXIR_X1 - ELIXIR_X0)
        best = max(best, fill)
    if best < 0.05:
        return 0
    return round(best * 10) if best < 0.95 else 10


def _scan_bar_fraction(img, xr, yr, is_enemy=False, max_span=132.0):
    """Scan a bounding box for a horizontal tower HP bar and return its fill
    fraction in [0.0, 1.0]. Returns 0.0 if the tower is destroyed/absent."""
    best_span = 0
    best_cnt = 0
    for y in yr:
        xs = []
        for x in xr:
            r, g, b = img.getpixel((x, y))
            if is_enemy:
                if r > 165 and g < 85 and b < 115 and r > b + 60:
                    xs.append(x)
            else:
                if b > 165 and g > 105 and r < 95 and b > r + 80:
                    xs.append(x)
        if len(xs) > best_cnt:
            best_cnt = len(xs)
            best_span = (max(xs) - min(xs)) if len(xs) >= 4 else 0
    if best_cnt < 5:
        return 0.0
    span_ratio = min(1.0, best_span / max_span)
    cnt_ratio = min(1.0, best_cnt / (max_span * 0.36))
    return round(max(span_ratio * 0.7 + cnt_ratio * 0.3, cnt_ratio), 3)


def tower_healths(img):
    """Full-vision scan of all 5 tower health bars on the battlefield."""
    al = _scan_bar_fraction(img, range(155, 340, 2), range(1360, 1450, 2), is_enemy=False, max_span=132.0)
    ar = _scan_bar_fraction(img, range(740, 920, 2), range(1360, 1450, 2), is_enemy=False, max_span=132.0)
    ak_raw = _scan_bar_fraction(img, range(430, 650, 2), range(1725, 1758, 2), is_enemy=False, max_span=152.0)
    ak = ak_raw if (ak_raw > 0.05 or al == 0.0 or ar == 0.0) else 1.0
    el = _scan_bar_fraction(img, range(155, 340, 2), range(370, 435, 2), is_enemy=True, max_span=132.0)
    er = _scan_bar_fraction(img, range(740, 920, 2), range(370, 435, 2), is_enemy=True, max_span=132.0)
    return {
        "ally_left": al,
        "ally_right": ar,
        "ally_king": ak,
        "enemy_left": el,
        "enemy_right": er,
        "ally_alive": int(al > 0.05) + int(ar > 0.05) + 1,
        "enemy_alive": int(el > 0.05) + int(er > 0.05) + 1,
    }


COUNTER_TABLE = {
    # card -> cards that BEAT it for less elixir (positive elixir trade)
    "valkyrie": ["minipekka", "musketeer", "archers"],
    "giant": ["minipekka", "cannon", "tesla", "skeletons"],
    "hogrider": ["cannon", "tesla", "valkyrie", "skeletons"],
    "minipekka": ["skeletons", "cannon"],
    "musketeer": ["skeletons", "fireball"],
    "knight": ["minipekka", "musketeer"],
    "archers": ["fireball", "arrows"],
    "wizard": ["fireball", "skeletons"],
    "minions": ["arrows", "zap", "musketeer"],
    "bomber": ["fireball"],
    "balloon": ["musketeer", "archers", "tesla"],
    "prince": ["skeletons", "minions"],
}
AIR_UNITS = {"minions", "balloon", "baby_dragon", "mega_minion", "bats"}


def counters_available(hand_deck, threat_name):
    """Returns which slots in hand hold a card that counters the threat."""
    good = COUNTER_TABLE.get(threat_name.lower(), [])
    return [i for i, c in enumerate(hand_deck) if c in good]


def scan_arena_vision(img):
    """Full-vision scan of active troop/building health bars across the arena."""
    enemy_left = 0
    enemy_right = 0
    enemy_bridge_l = 0
    enemy_bridge_r = 0
    ally_left = 0
    ally_right = 0
    for y in range(480, 1650, 8):
        for x in range(100, 980, 8):
            r, g, b = img.getpixel((x, y))
            if r > 180 and g < 70 and b < 95 and r > b + 90:
                if x < 540:
                    enemy_left += 1
                    if y > 850:
                        enemy_bridge_l += 1
                else:
                    enemy_right += 1
                    if y > 850:
                        enemy_bridge_r += 1
            elif b > 175 and g > 110 and r < 85 and b > r + 90:
                if x < 540:
                    ally_left += 1
                else:
                    ally_right += 1
    # air detection: flying units have no shadow band
    air = 0
    for y in range(480, 1650, 10):
        for x in range(150, 950, 10):
            r, g, b = img.getpixel((x, y))
            if r > 175 and g > 175 and b > 120 and g - r < 25 and b - g < 25:
                air += 1
    return {
        "enemy_left": enemy_left,
        "enemy_right": enemy_right,
        "enemy_bridge_l": enemy_bridge_l,
        "enemy_bridge_r": enemy_bridge_r,
        "ally_left": ally_left,
        "ally_right": ally_right,
        "air_threat": air,
        # HP-mass proxy: bigger bar areas ≈ tank champions; counters/kite decisions use this
        "enemy_hp_mass_l": round(enemy_left * 2.6, 1),
        "enemy_hp_mass_r": round(enemy_right * 2.6, 1),
        "ally_hp_mass_l": round(ally_left * 2.6, 1),
        "ally_hp_mass_r": round(ally_right * 2.6, 1),
    }


def hand_affordability(img, mlxir):
    """True pixel-level card affordability check: scans the pink/magenta elixir
    drop badge beneath each of the 4 cards in hand (y=2160..2235)."""
    centers = [332, 543, 737, 931]
    afford = []
    for cx in centers:
        pink = sum(
            1 for y in range(2160, 2235, 4) for x in range(cx - 35, cx + 40, 4)
            if img.getpixel((x, y))[0] > 150
            and img.getpixel((x, y))[2] > 130
            and img.getpixel((x, y))[1] < 100
        )
        afford.append(1.0 if pink >= 8 else 0.0)
    if sum(afford) == 0 and mlxir >= 2:
        afford[mlxir % 4] = 1.0
    return afford


def _any(img, tests):
    return sum(1 for _ in range(1) if False) if False else None


# ============================================================
# GAME RULES OF CLASH ROYALE — the brain is taught the actual law
# ============================================================
ELIXIR_REGEN_PER_TICK = 0.7        # ~1 elixir / 2.8s in-game
TOWER_FINISH_THRESHOLD = 0.32      # under ~30% HP a cheap spell can finish
SPELL_FINISH_MIN_DAMAGE = 0.18     # spell must cover at least ~18% of tower HP


def tower_finish_check(towers, hand_deck, mlxir):
    """RULE: a spell held in hand must NOT be dropped at bridge when an enemy
    tower is under finish range — instead route slots holding that spell as a
    'finisher' so the play policy aims it AT THE TOWER (kill = 1000-2600 dmg)."""
    finishers = []
    for side, key in (("left", "enemy_left"), ("right", "enemy_right")):
        hp = towers.get(key, 1.0)
        if 0.0 < hp <= TOWER_FINISH_THRESHOLD:
            for slot_idx, name in enumerate(hand_deck[:4]):
                info = CARDS_DB.get(name, {})
                if info.get("role") == "spell" and info.get("cost", 9) <= mlxir:
                    # Rough damage coverage: fireball 33%, arrows 17%, zap 12% of avg tower HP
                    dmg_est = {"fireball": 0.33, "arrows": 0.17, "zap": 0.12}.get(name, 0.0)
                    if dmg_est >= hp - 0.02:
                        finishers.append({"side": side, "slot": slot_idx,
                                          "dmg": dmg_est, "tower_hp": hp})
    return finishers


def card_play_policy(action, mlxir, lane, arena, towers, afford, hand_deck, finishers=None):
    """Knowledge-based veto/redirect layer ON TOP of the network choose:
    the net proposes, the RULES referee. Returns possibly-corrected action.
      - spell at bridge -> redirect to tower finisher if a finisher exists
      - spell center_back (pointless) -> redirect to defense/finisher
      - heavy tank at bridge when elixir < cost+1 (can't support) -> center_back
      - cheap cycle card at bridge with no push and no threat -> defend instead
    """
    if not hand_deck:
        return action, "net"
    slot, spot_i = divmod(action, 5)
    if slot >= len(hand_deck) or not afford or slot >= len(afford) or afford[slot] < 0.5:
        return action, "net"
    name = (hand_deck[slot] or "").lower()
    info = CARDS_DB.get(name, {})
    role = info.get("role", "support")
    spot_n = SPOT_NAMES[spot_i]

    # RULE 1: spell finisher — aim at the weak tower instead of a bridge drop
    if role == "spell" and finishers:
        f = min(finishers, key=lambda x: x["tower_hp"])
        finish_spot = 0 if f["side"] == "left" else 1   # bridge_left/bridge_right rows hit tower area
        return f["slot"] * 5 + finish_spot, f"finisher->{f['side']}"
    # RULE 2: spells never "defend" — waste; prefer a finisher or center_back
    if role == "spell" and spot_n in ("left_defend", "right_defend"):
        return slot * 5 + 4, "spell_no_defend"   # center_back = cast mid-field (value)
    # RULE 3: heavy commitment discipline — tank/win_condition needs elixir support
    if role in ("tank", "win_condition") and spot_n.startswith("bridge"):
        if mlxir < info.get("cost", 5) + 1:
            return slot * 5 + 4, "commit discipline (needs support elixir)"
    # RULE 4: cheap cycle: don't burn the cycle card at a bridge alone
    if info.get("cost", 9) <= 2 and spot_n.startswith("bridge"):
        threat = arena.get("enemy_bridge_l", 0) + arena.get("enemy_bridge_r", 0)
        if threat == 0:
            return slot * 5 + 4, "cheap-cycle discipline (save for defense)"
    # RULE 5: buildings go at the center to pull pushes, never at the bridge
    if role == "building" and spot_n.startswith("bridge"):
        return slot * 5 + 4, "building pulls center"
    return action, "net"


# ============================================================
# OPPONENT MEMORY — remember what the enemy played, across matches
# ============================================================
OPPONENT_MEMORY_FILE = "opponent_memory.json"
GAME_MEMORY_FILE = "game_memory.json"


def _load_game_memory():
    try:
        return json.load(open(GAME_MEMORY_FILE))
    except Exception:
        return {"matches": [], "spot_ledger": {}, "winrate_history": []}


def distill_match(verdict, stats):
    """Distill a finished match into the long-term memory book — NOT the raw
    replay, a compressed story: outcome, dopamine total, lanes faced, which
    spots paid off. This is what the brain 'remembers about games'."""
    mem = _load_game_memory()
    matches = mem.setdefault("matches", [])
    matches.append({
        "t": time.strftime("%m-%d %H:%M"),
        "v": verdict,
        "dop": round(stats.get("reward_total", 0.0), 1),
        "ticks": stats.get("ticks", 0),
        "cards": stats.get("cards_played", 0),
        "pushes_faced": stats.get("pushes_faced", 0),
        "towers_down": stats.get("towers_down", 0),
        "towers_lost": stats.get("towers_lost", 0),
        "rule_corrections": stats.get("rule_corrections", 0),
    })
    mem["matches"] = matches[-200:]
    # Spot ledger: which placements historically earned dopamine
    ledger = mem.setdefault("spot_ledger", {})
    for spot, (tot, n) in stats.get("spot_totals", {}).items():
        cur = ledger.get(spot, [0.0, 0])
        ledger[spot] = [round(cur[0] + tot, 2), cur[1] + n]
    recent = mem["matches"][-100:]
    wins = sum(1 for m in recent if m["v"] == "WIN")
    mem["winrate_history"] = (mem.get("winrate_history", []) + [wins])[-100:]
    try:
        json.dump(mem, open(GAME_MEMORY_FILE, "w"), indent=1)
    except Exception:
        return {}
    return game_memory_digest(mem)


def game_memory_digest(mem=None):
    """Compact human/JSON readable summary of everything remembered."""
    if mem is None:
        mem = _load_game_memory()
    matches = mem.get("matches", [])
    if not matches:
        return {"games_remembered": 0}
    last100 = matches[-100:]
    wins = sum(1 for m in last100 if m["v"] == "WIN")
    ledger = mem.get("spot_ledger", {})
    ranked = sorted(
        ((s, t / max(1, n)) for s, (t, n) in ledger.items() if n >= 3),
        key=lambda x: x[1], reverse=True)
    best = ranked[:2]
    worst = ranked[-2:]
    avg_dop = round(sum(m["dop"] for m in last100) / max(1, len(last100)), 2)
    towers_down = sum(m.get("towers_down", 0) for m in last100)
    pushes = sum(m.get("pushes_faced", 0) for m in last100)
    return {
        "games_remembered": len(matches),
        "recent_winrate": round(100.0 * wins / max(1, len(last100)), 1),
        "avg_dopamine_per_match": avg_dop,
        "best_spots": [(s, round(v, 2)) for s, v in best],
        "avoid_spots": [(s, round(v, 2)) for s, v in worst if v < 0],
        "towers_destroyed_recent": towers_down,
        "enemy_pushes_faced_recent": pushes,
        "one_line": (
            f"remembers {len(matches)} games · winrate {round(100.0*wins/max(1,len(last100))):.0f}% last {len(last100)} · "
            f"plays best: {', '.join(s for s,_ in best[:2]) or 'n/a'} · "
            f"worst: {', '.join(s for s,_ in worst[:1]) or 'n/a'}"
        ),
    }


def _load_opponent_memory():
    try:
        return json.load(open(OPPONENT_MEMORY_FILE))
    except Exception:
        return {"recent_opponents": [], "matches_total": 0}


def _save_opponent_memory(mem):
    try:
        keep = mem.get("recent_opponents", [])[-30:]
        mem["recent_opponents"] = keep
        mem["matches_total"] = mem.get("matches_total", 0) + 1
        json.dump(mem, open(OPPONENT_MEMORY_FILE, "w"), indent=1)
    except Exception:
        pass


def opponent_new_match():
    """Start tracking a fresh opponent."""
    return {"cards_played": [], "elixir_spent": 0, "pushes": [], "start": time.time()}


def opponent_observe(opp, arena_prev, arena_now, towers_prev, towers_now):
    """Update the opponent model this match: it sees enemy troops crossing the
    bridge (vision counts them) and enemy damage spikes (a play was made)."""
    if not opp:
        return
    e_now = arena_now.get("enemy_left", 0) + arena_now.get("enemy_right", 0)
    e_prev = (arena_prev or {}).get("enemy_left", 0) + (arena_prev or {}).get("enemy_right", 0)
    # A wave coming over the bridge: units >6 in a lane the previous frame lacked
    for side in ("left", "right"):
        now_n = arena_now.get(f"enemy_{side}", 0)
        prev_n = (arena_prev or {}).get(f"enemy_{side}", 0)
        if now_n >= 6 and prev_n < now_n // 2:
            opp["pushes"].append({"side": side, "size": now_n, "tick": time.time()})
            opp["cards_played"].append("unknown")
    if e_now - e_prev >= 5:
        opp["cards_played"].append("unknown")
    # enemy tower took big damage from us: they were distracted, commit
    el = max(0.0, (towers_prev or {}).get("enemy_left", 1) - towers_now.get("enemy_left", 1))
    er = max(0.0, (towers_prev or {}).get("enemy_right", 1) - towers_now.get("enemy_right", 1))
    if el + er >= 0.08:
        opp["elixir_spent"] += 2
    return opp


def classify(img):
    """Hard pixel-signature classifier calibrated on real screenshots.
    Order matters: most specific first."""
    # 0. Dimmed result overlay: extremely dark scene + faint blue OK button glow
    import statistics as _st
    _px = [sum(img.getpixel((x, y))) / 3 for y in range(400, 2000, 200) for x in range(200, 900, 300)]
    if _st.mean(_px) < 25:
        return "result"  # dimmed end-of-match overlay (WIN/LOSS) — tap OK
    # 1. Supercell ID sign-in / loading sheet: huge pure-white area mid-screen
    sc_white = sum(1 for y in range(1000, 2000, 50) for x in range(100, 980, 60)
                   if img.getpixel((x, y))[0] > 235 and img.getpixel((x, y))[1] > 235
                   and img.getpixel((x, y))[2] > 235)
    if sc_white >= 120:
        return "popup"  # non-interactive loading sheet: press BACK/OK
    # 2. Quit dialog: red Cancel left + blue OK right at y=1480
    red_c = sum(1 for x in range(270, 450, 15) if img.getpixel((x, 1480))[0] > 180 and img.getpixel((x, 1480))[1] < 90)
    blue_ok = sum(1 for x in range(620, 800, 15) if img.getpixel((x, 1480))[2] > 180 and img.getpixel((x, 1480))[0] < 90)
    if red_c >= 6 and blue_ok >= 6:
        return "quit_dialog"
    # 3. Battle: pink elixir drop icon bottom-left
    pink_drop = sum(1 for y in range(2260, 2325, 6) for x in range(205, 265, 6)
                    if img.getpixel((x, y))[0] > 170 and img.getpixel((x, y))[2] > 150
                    and img.getpixel((x, y))[1] < 110)
    if pink_drop >= 18:
        return "battle"
    # 4. Result screen: blue OK button bottom-center OR (blue/red ribbon + OK)
    ok_blue = sum(1 for y in (2035, 2060, 2085) for x in range(450, 630, 15)
                  if img.getpixel((x, y))[2] > 150 and img.getpixel((x, y))[1] > 80
                  and img.getpixel((x, y))[0] < 110)
    if ok_blue >= 12:
        return "result"
    # 5. Battle-tab lobby: bright yellow Battle button
    yellow_btn = sum(1 for y in (1850, 1880, 1910) for x in range(380, 700, 25)
                     if img.getpixel((x, y))[0] > 210 and 120 < img.getpixel((x, y))[1] < 215
                     and img.getpixel((x, y))[2] < 80)
    if yellow_btn >= 20:
        return "lobby"
    # 6. Other lobby tab (shop/collection/clan/events): top resource bar gold+gem
    green_gem = sum(1 for y in range(50, 90, 5) for x in range(725, 785, 5)
                    if img.getpixel((x, y))[1] > 170 and img.getpixel((x, y))[1] > img.getpixel((x, y))[0] + 50
                    and img.getpixel((x, y))[1] > img.getpixel((x, y))[2] + 40)
    gold_coin = sum(1 for y in range(50, 90, 5) for x in range(420, 470, 5)
                    if img.getpixel((x, y))[0] > 200 and img.getpixel((x, y))[1] > 140
                    and img.getpixel((x, y))[2] < 80)
    if green_gem >= 6 and gold_coin >= 6:
        return "other_tab"
    # 7. Blue ribbon (result loading behind overlay)
    band = [img.getpixel((x, y)) for y in (1400, 1440) for x in range(240, 880, 60)]
    blue_rib = sum(1 for r, g, b in band if b > 140 and b > r + 40)
    if blue_rib >= 18:
        return "result"
    return "unknown"


HIPPOCAMPUS_FILE = "hippocampus.jsonl"
_hippo_lock = threading.Lock()
brain_ref = [None]  # set by main() so hippocampal_write can enrich with Q/V/A

def hippocampal_write(entry):
    """Long-term memory archive: append every rich transition to a monotonic
    .jsonl. Unlike ml_replay.json (bounded), this grows unbounded — it is the
    path to GB-scale memory. Read back with random retrievals when training.
    Rich-mode: every entry also carries the full 38-dim state vectors for BOTH
    s and s2, towers, arena, elixir, verdict context and pain-channel state,
    so each line is ~1.4 KB instead of ~0.1 KB — reach GB scale ~14× faster."""
    try:
        e = dict(entry)
        q, v, a, *_hid = brain_ref[0].policy.forward_streams(
            torch.tensor(e["s"], dtype=torch.float32)) if brain_ref[0] else ((None,)*8)
        if q is not None:
            e["q_row"] = [round(v_, 4) for v_ in q.tolist()]
            e["V_export"] = round(v.item(), 4)
            e["advantages"] = [round(v_, 4) for v_ in a.tolist()]
        e["ctx"] = {
            "towers": e.pop("towers", None),
            "arena": e.pop("arena", None),
            "pain_avg": e.pop("pain_avg", None),
        }
        e["ctx"] = {k: v_ for k, v_ in e["ctx"].items() if v_ is not None}
        with _hippo_lock:
            with open(HIPPOCAMPUS_FILE, "a", encoding="utf-8") as f:
                f.write(json.dumps(e) + "\n")
    except Exception:
        # never let memory archiving break the battle loop
        try:
            with _hippo_lock:
                with open(HIPPOCAMPUS_FILE, "a", encoding="utf-8") as f:
                    f.write(json.dumps({"minimal": True, **{k: entry.get(k) for k in ("t", "a", "r")}}) + "\n")
        except Exception:
            pass
    try:
        with _hippo_lock:
            with open(HIPPOCAMPUS_FILE, "a", encoding="utf-8") as f:
                f.write(json.dumps(entry) + "\n")
    except Exception:
        pass

def hippocampal_sample(k=32):
    """Randomly sample k past experiences from the archive for consolidation
    (like pamięci sleep replay). Falls back silently when the file is small."""
    try:
        import random as _r
        with _hippo_lock:
            size = os.path.getsize(HIPPOCAMPUS_FILE)
            with open(HIPPOCAMPUS_FILE, "rb") as f:
                picks = []
                for _ in range(k):
                    pos = max(0, _r.randrange(int(size * 0.9)))
                    f.seek(pos)
                    f.readline()   # partial line
                    line = f.readline()
                    if line:
                        picks.append(json.loads(line))
                return picks
    except Exception:
        return []


def judge_match_result(img):
    """AUTHORITATIVE WIN/LOSS judge: reads the crown ribbon strip across THREE
    y-bands and the score strip; the winner's ribbon is BRIGHT SATURATED color
    while the loser's is desaturated/dark. Requires a clear margin; defaults to
    LOSS when unclear (a false WIN poisons the reward signal far worse)."""
    bands = [(y0, [(x, y) for y in range(y0, y0 + 40, 8) for x in range(200, 880, 40)])
             for y0 in (1370, 1410, 1450)]
    reds, blues = 0, 0
    for _, cells in bands:
        for (x, y) in cells:
            r, g, b = img.getpixel((x, y))
            sat = max(r, g, b) - min(r, g, b)
            if r > 140 and sat > 60 and r > b + 30:
                reds += 1
            elif b > 140 and sat > 60 and b > r + 30:
                blues += 1
    if reds >= blues + 8:
        return "LOSS"     # red ribbon dominates = we lost
    if blues >= reds + 8:
        return "WIN"
    return "LOSS"         # unclear → never claim a false win


def lane_variances(img):
    """Fast lane variance on a downsampled crop (40×80 grid instead of full 400×400).
    ~6ms instead of ~600ms."""
    import statistics

    def variance(box):
        region = [img.getpixel((x, y)) for y in range(box[1], box[3], 10) for x in range(box[0], box[2], 8)]
        rs = [p[0] for p in region]
        gs = [p[1] for p in region]
        return statistics.pstdev(rs) + statistics.pstdev(gs)

    left = variance((100, 1500, 500, 1900))
    right = variance((580, 1500, 980, 1900))
    return left, right


def match_phase(img, tick_count):
    if tick_count < 15:
        return 0  # early
    if tick_count < 45:
        return 1  # mid
    return 2  # late


CARDS = [(263, 2230), (470, 2230), (676, 2230), (883, 2230)]  # current in-game hand slots (y=2230 row)
SPOT_NAMES = ["bridge_left", "bridge_right", "left_defend", "right_defend", "center_back"]
FIELD_SPOTS = {
    "left_defend": (337, 1250),
    "right_defend": (742, 1250),
    "center_back": (540, 1300),
    "bridge_left": (220, 980),
    "bridge_right": (860, 980),
}
BATTLE_BUTTON = (540, 1945)  # current in-game Battle button
CANCEL_BUTTON = (365, 1480)
OK_CENTER = (540, 2050)
RESULT_OK = (540, 1990)  # dimmed result-screen OK sits higher (~y1990)
CLAIM_SPOT = (700, 1420)
TOP_BATTLE_TAB = (150, 300)

OPPONENT_VOCAB = [
    "hogrider", "giant", "minipekka", "musketeer", "knight", "archers",
    "valkyrie", "skeletons", "fireball", "arrows", "zap", "cannon",
    "tesla", "wizard", "bomber", "minions",
]

SPOT_TO_ACTION.update({n: i for i, n in enumerate(SPOT_NAMES)})


# ============================================================
# SYNAPTIC PAIN CHANNELS — Hebbian tags on (card_slot, spot) that get
# sensitivity-reduced after painful outcomes, so the same mistake fires less.
# Analogy: long-term depression (LTD) at the synaptic channel level.
# ============================================================
PAIN_FILE = "pain_channels.json"

def _load_pain_channels():
    try:
        return {(int(k.split(',')[0]), int(k.split(',')[1])): float(v)
                for k, v in json.load(open(PAIN_FILE)).items()}
    except Exception:
        return {}

def _save_pain_channels(ch):
    try:
        json.dump({f"{k[0]},{k[1]}": round(v, 3) for k, v in list(ch.items())[-400:]},
                  open(PAIN_FILE, "w"))
    except Exception:
        pass

def pain_stimulus(base_reward, slot, spot, pain_channels):
    """Pain gate: a channel that recently averaged strongly negative gets its
    baseline activation scaled down (like LTD), so repeat mistakes feel more
    painful AND fire less. Returns (effective_reward, pain_event_or_None)."""
    key = (slot, spot)
    historic = pain_channels.get(key)
    if historic is None:
        return base_reward, None
    pain_factor = min(1.0, max(0.25, 1.0 + historic / 8.0))   # deep pain → up to ×4 sensitivity
    if pain_factor < 0.99 and base_reward < -0.05:
        boosted = base_reward / pain_factor
        label = f"🔥 PAIN channel {slot},{spot} (avg {historic:+.1f}) amplifies this mistake"
        return boosted, (label, boosted - base_reward)
    return base_reward, None

def record_pain(ch, slot, spot, reward):
    """EMA update of the channel's pain memory each tick it fires."""
    key = (slot, spot)
    old = ch.get(key, 0.0)
    ch[key] = old * 0.92 + reward * 0.08
    return ch


def q_state_fired(q_state):
    """The 38 sensory neurons and WHAT each one senses, for the dashboard's
    labeled input-row firing display."""
    senses = (
        "elixir", "lane_variance_L bars", "lane_variance_R bars",
        "cost slot0", "cost slot1", "cost slot2", "cost slot3",
        "afford slot0", "afford slot1", "afford slot2", "afford slot3",
        "phase early", "phase mid", "phase late",
        "last slot0", "last slot1", "last slot2", "last slot3",
        "last spot bridge_L", "last spot bridge_R", "last spot def_L",
        "last spot def_R", "last spot center",
        "my tower L", "my tower R", "my king", "enemy tower L", "enemy tower R",
        "towers alive (me)", "towers alive (enemy)",
        "units enemy L", "units enemy R", "push enemy bridge L",
        "push enemy bridge R", "units ally L", "units ally R",
        "threat L", "threat R", "extra",
    )
    return [{"v": round(float(x), 3), "sense": senses[i] if i < len(senses) else f"s{i}"}
            for i, x in enumerate(q_state)]


# ---------------------- Advanced Neural Architecture (Dueling ResNet QNet) ----------------------
class SynapticResBlock(nn.Module):
    """Residual cortical column with LayerNorm + SiLU activation so deep neuron
    gearing trains smoothly with skip connections."""
    def __init__(self, dim=128):
        super().__init__()
        self.fc1 = nn.Linear(dim, dim)
        self.ln1 = nn.LayerNorm(dim)
        self.fc2 = nn.Linear(dim, dim)
        self.ln2 = nn.LayerNorm(dim)
        self.act = nn.SiLU()

    def forward(self, x):
        h = self.act(self.ln1(self.fc1(x)))
        h = self.ln2(self.fc2(h))
        return self.act(x + h)


class QNet(nn.Module):
    """Dueling Surge-Neuron Architecture v3 (MASSIVE cortex — disk budget is free):
      - Sensory Input Stem (38 -> 512 + LayerNorm + SiLU)
      - 4 Residual Synaptic Cortical Blocks (512 -> 512)  ≈ 8.4M cortical synapses
      - Limbic State-Value stream V(s): 512 -> 256 -> 1
      - Motor Action-Advantage stream A(s,a): 512 -> 256 -> 20
      - Aggregated Q(s,a) = V(s) + (A(s,a) - mean_a A(s,a))
    ~8.6M trainable parameters ≈ 35 MB fp32 weights on disk — the brain is now
    big enough to represent deck synergies, counter-relationships and
    meta-strategy, not just reflexes. Trains on CPU well with batch 128.
    """
    def __init__(self):
        super().__init__()
        self.sensory = nn.Sequential(
            nn.Linear(STATE_DIM, 512),
            nn.LayerNorm(512),
            nn.SiLU(),
        )
        self.cortex1 = SynapticResBlock(512)
        self.cortex2 = SynapticResBlock(512)
        self.cortex3 = SynapticResBlock(512)
        self.cortex4 = SynapticResBlock(512)

        # Limbic State-Value stream V(s)
        self.value_stream = nn.Sequential(
            nn.Linear(512, 256),
            nn.LayerNorm(256),
            nn.SiLU(),
            nn.Linear(256, 1),
        )
        # Motor Action-Advantage stream A(s,a)
        self.advantage_stream = nn.Sequential(
            nn.Linear(512, 256),
            nn.LayerNorm(256),
            nn.SiLU(),
            nn.Linear(256, ACTION_DIM),
        )

    def forward_streams(self, x):
        single = x.dim() == 1
        if single:
            x = x.unsqueeze(0)
        h0 = self.sensory(x)
        h1 = self.cortex1(h0)
        h2 = self.cortex2(h1)
        h3 = self.cortex3(h2)
        h4 = self.cortex4(h3)
        v_hid = self.value_stream[:-1](h4)
        a_hid = self.advantage_stream[:-1](h4)
        v = self.value_stream[-1](v_hid)
        a = self.advantage_stream[-1](a_hid)
        q = v + (a - a.mean(dim=-1, keepdim=True))
        if single:
            return (q.squeeze(0), v.squeeze(0), a.squeeze(0), h1.squeeze(0),
                    h2.squeeze(0), h3.squeeze(0), h4.squeeze(0), v_hid.squeeze(0))
        return q, v, a, h1, h2, h3, h4, v_hid

    def forward(self, x):
        return self.forward_streams(x)[0]


METRICS_FILE = "ml_metrics.json"
TRAIN_LOG = open("training.log", "a", buffering=1, encoding="utf-8", errors="replace")
MENTOR_LOG = open("mentor.log", "a", buffering=1, encoding="utf-8", errors="replace")
COACH_FILE = "ai_coach.jsonl"
_metrics = {
    "architecture": "Dueling-Double-DQN + PER + 3-Step + Groq-VLM",
    "steps": 0,
    # Seed the game-memory digest so the dashboard shows it even before the
    # first distill of this session (distill_match refreshes it every match end).
    "game_memory": {},
    "opponent_memory": {"known": 0, "this_match_pushes": 0},
    "dopamine_events": [],
    "win_history": [],
    "wins_v": 0,
    "losses_v": 0,
    "losses": [],
    "td_errors": [],
    "epsilon": 0.35,
    "buffer": 0,
    "actions_taken": {},
    "rewards": [],
    "damage_punishments": [],
    "mentor_reviews": 0,
    "mentor_agree": 0,
    "matches": 0,
}


def metrics_append(loss, reward=None, action=None, dmg_punish=None, vision=None, td_err=None, mentor=None):
    """Every-train-step + every-action record into training.log and ml_metrics.json."""
    _metrics["steps"] += 1
    if loss is not None:
        _metrics["losses"].append(round(loss, 5))
        _metrics["losses"] = _metrics["losses"][-500:]
        td_str = f" td_err={td_err:.4f}" if td_err is not None else ""
        TRAIN_LOG.write(
            f"[{time.strftime('%H:%M:%S')}] step={_metrics['steps']} "
            f"loss={loss:.5f}{td_str} eps={_metrics['epsilon']:.3f} buffer={_metrics['buffer']}\n"
        )
    if td_err is not None:
        _metrics["td_errors"].append(round(td_err, 4))
        _metrics["td_errors"] = _metrics["td_errors"][-300:]
    if reward is not None:
        _metrics["rewards"].append(round(reward, 3))
        _metrics["rewards"] = _metrics["rewards"][-500:]
    if dmg_punish is not None:
        _metrics["damage_punishments"].append(round(dmg_punish, 3))
        _metrics["damage_punishments"] = _metrics["damage_punishments"][-200:]
    if vision is not None:
        _metrics["vision"] = vision
    if mentor is not None:
        _metrics["last_mentor"] = mentor
    if action is not None:
        _metrics["actions_taken"][str(action)] = _metrics["actions_taken"].get(str(action), 0) + 1
    try:
        with open(METRICS_FILE, "w") as f:
            json.dump(_metrics, f, indent=1)
    except Exception:
        pass


class TargetedDQN:
    """Advanced Dueling Double DQN with:
      - Prioritized Experience Replay (PER, proportional TD-error priorities)
      - 3-Step Bootstrapping queue (propagates tower-damage punishment 3x faster)
      - Polyak Soft Target Updates
      - Legacy checkpoint migration (upgrades older checkpoints seamlessly)
    """
    def __init__(self):
        self.policy = QNet()
        self.target = QNet()
        self.target.load_state_dict(self.policy.state_dict())
        self.optim = optim.AdamW(self.policy.parameters(), lr=8e-4, weight_decay=1e-4)
        # GB-scale memory: 120k transitions × ~0.5 KB heavy states ≈ up to ~60 MB
        # in RAM, replay JSON dumps to disk every checkpoint so DOWNLOADERS and
        # restarts keep every memory. (A few GB on disk is achievable via
        # per-state detail; this is the practical sweet spot for CPU training.)
        self.buffer = deque(maxlen=400000)
        self.priorities = deque(maxlen=400000)
        self.nstep_queue = deque(maxlen=3)
        self.n_steps = 3
        self.epsilon = 0.35
        self.gamma = 0.95
        self.batch = 128     # massive cortex deserves massive minibatches
        self.train_every = 2  # Train every 2 battle ticks for faster convergence
        self.per_alpha = 0.6
        self.per_beta = 0.4
        self.tau = 0.015
        self._memory_dirty = 0

    def dopamine_report(self, q_state):
        """Per-neuron gearing telemetry across Sensory/Cortical/Limbic/Advantage streams.
        Includes per-neuron arrays so the dashboard can draw a real firing brain."""
        with torch.no_grad():
            x = torch.tensor(q_state, dtype=torch.float32)
            q, v, a, h1, h2, h3, h4, v_hid = self.policy.forward_streams(x)
            return {
                "layer1_mean": round(h1.abs().mean().item(), 3),
                "layer2_mean": round(h2.abs().mean().item(), 3),
                "layer3_mean": round(h3.abs().mean().item(), 3),
                "limbic_mean": round(v_hid.abs().mean().item(), 3),
                "state_value_V": round(v.item(), 3),
                "advantage_spread": round((a.max() - a.min()).item(), 3),
                "output_best": int(q.argmax().item()),
                "output_value": round(q.max().item(), 3),
                # FULL-depth per-neuron activations (dashboard draws live brain)
                "sensory_neurons": q_state_fired(q_state),
                "layer1_neurons": [round(v_, 3) for v_ in h1.tolist()],
                "layer2_neurons": [round(v_, 3) for v_ in h2.tolist()],
                "layer3_neurons": [round(v_, 3) for v_ in h3.tolist()],
                "layer4_neurons": [round(v_, 3) for v_ in h4.tolist()],
                "limbic_neurons": [round(v_, 3) for v_ in v_hid.tolist()],
                "actions_desc": [SPOT_NAMES[i % 5] for i in range(ACTION_DIM)],
                "advantage_neurons": [round(v_, 3) for v_ in a.tolist()],
            }

    def act(self, state, forbidden=None):
        if random.random() < self.epsilon:
            a = random.randrange(ACTION_DIM)
            tries = 0
            while forbidden and a in forbidden and tries < 40:
                a = random.randrange(ACTION_DIM)
                tries += 1
            return a
        with torch.no_grad():
            q = self.policy(torch.tensor(state, dtype=torch.float32)).clone()
            if forbidden:
                for f in forbidden:
                    if f < ACTION_DIM:
                        q[f] = -1e9
            return int(torch.argmax(q).item())

    def _push_per(self, transition, init_prio=None):
        self.buffer.append(transition)
        if init_prio is None:
            max_p = max(self.priorities) if self.priorities else 1.0
            # Boost initial priority for severe punishment or major reward
            r = transition[2]
            boost = 2.0 if abs(r) >= 1.0 else 1.0
            init_prio = max_p * boost
        self.priorities.append(float(max(1e-3, init_prio)))
        self._memory_dirty += 1

    def remember(self, s, a, r, s2, done):
        """Store 1-step transition immediately AND accumulate 3-step return
        transitions so delayed tower-damage punishments propagate rapidly."""
        self.nstep_queue.append((s, a, float(r), s2, bool(done)))
        # Compute N-step discounted return from the oldest transition in the queue
        if len(self.nstep_queue) == self.n_steps or done:
            while self.nstep_queue:
                s0, a0, _, _, _ = self.nstep_queue[0]
                R = 0.0
                final_s2 = s2
                final_done = False
                steps_used = 0
                for idx, (_, _, r_k, s2_k, d_k) in enumerate(self.nstep_queue):
                    R += (self.gamma ** idx) * r_k
                    final_s2 = s2_k
                    steps_used = idx + 1
                    if d_k:
                        final_done = True
                        break
                self._push_per([s0, int(a0), round(R, 4), final_s2, final_done, steps_used])
                self.nstep_queue.popleft()
                if not done:
                    break

    def train_step(self):
        n = len(self.buffer)
        if n < self.batch:
            return None
        # Ensure priorities match buffer length
        while len(self.priorities) < n:
            self.priorities.append(1.0)

        # Prioritized Experience Replay (PER) sampling
        prios = [max(1e-4, float(p)) ** self.per_alpha for p in self.priorities]
        total_p = sum(prios)
        probs = [p / total_p for p in prios]
        indices = random.choices(range(n), weights=probs, k=self.batch)

        # Anneal importance-sampling beta toward 1.0
        self.per_beta = min(1.0, self.per_beta + 0.001)
        weights = [(n * probs[i]) ** (-self.per_beta) for i in indices]
        max_w = max(weights) if weights else 1.0
        weights = [w / max_w for w in weights]

        batch = [self.buffer[i] for i in indices]
        s = torch.tensor([b[0] for b in batch], dtype=torch.float32)
        a = torch.tensor([b[1] for b in batch], dtype=torch.long)
        r = torch.tensor([b[2] for b in batch], dtype=torch.float32)
        s2 = torch.tensor([b[3] for b in batch], dtype=torch.float32)
        d = torch.tensor([float(b[4]) for b in batch], dtype=torch.float32)
        n_step = torch.tensor([float(b[5]) if len(b) > 5 else 1.0 for b in batch], dtype=torch.float32)
        w_tensor = torch.tensor(weights, dtype=torch.float32)

        # Current Q(s, a)
        q = self.policy(s).gather(1, a.unsqueeze(1)).squeeze(1)

        # Double DQN Target: online policy selects best next action, target net evaluates it
        with torch.no_grad():
            next_actions = self.policy(s2).argmax(dim=1, keepdim=True)
            q_next = self.target(s2).gather(1, next_actions).squeeze(1)
            gammas = self.gamma ** n_step
            q_exp = r + gammas * q_next * (1.0 - d)

        td_errors = (q - q_exp).detach().abs()
        elementwise_loss = nn.functional.smooth_l1_loss(q, q_exp, reduction="none")
        loss = (w_tensor * elementwise_loss).mean()

        self.optim.zero_grad()
        loss.backward()
        nn.utils.clip_grad_norm_(self.policy.parameters(), 1.0)
        self.optim.step()

        # Update PER priorities with latest TD errors
        td_list = td_errors.tolist()
        for idx_pos, buf_idx in enumerate(indices):
            if buf_idx < len(self.priorities):
                # Extra priority boost if the transition involved punishment (r < -0.4)
                punish_boost = 1.5 if batch[idx_pos][2] <= -0.45 else 1.0
                self.priorities[buf_idx] = (td_list[idx_pos] + 1e-3) * punish_boost

        # Polyak soft target update every training step
        self.soft_update_target()

        value = loss.item()
        mean_td = float(td_errors.mean().item())
        _metrics["buffer"] = len(self.buffer)
        _metrics["epsilon"] = self.epsilon
        metrics_append(value, td_err=mean_td)
        return value

    def soft_update_target(self):
        with torch.no_grad():
            for tp, pp in zip(self.target.parameters(), self.policy.parameters()):
                tp.data.mul_(1.0 - self.tau).add_(pp.data, alpha=self.tau)

    def sync_target(self):
        self.target.load_state_dict(self.policy.state_dict())

    def save(self):
        torch.save({
            "arch": "dueling_resnet_v3_massive",
            "policy": self.policy.state_dict(),
            "target": self.target.state_dict(),
            "epsilon": self.epsilon,
        }, "ml_policy.pt")
        try:
            with open("ml_replay.json", "w") as f:
                json.dump(list(self.buffer)[-60000:], f)
            self._memory_dirty = 0
        except Exception as e:
            log(f"replay dump failed: {e}")

    def load(self):
        if os.path.exists("ml_policy.pt"):
            try:
                ckpt = torch.load("ml_policy.pt")
                self.epsilon = ckpt.get("epsilon", 0.35)
                if ckpt.get("arch") == "dueling_resnet_v3_massive":
                    self.policy.load_state_dict(ckpt["policy"])
                    self.target.load_state_dict(ckpt.get("target", ckpt["policy"]))
                    log(f"loaded Dueling-ResNet v3-MASSIVE (512×4) brain, epsilon={self.epsilon:.2f}")
                elif ckpt.get("arch") in ("dueling_resnet_v11_wide", "dueling_resnet_v10"):
                    # UPGRADE MIGRATION: sensory stem partial copy (works for any
                    # narrower predecessor), the rest starts fresh but learns fast
                    # from the big replay buffer.
                    old_sd = ckpt.get("policy", {})
                    with torch.no_grad():
                        w = self.policy.sensory[0].weight  # (512, 38)
                        b = self.policy.sensory[0].bias
                        try:
                            ow = old_sd.get("sensory.0.weight")
                            ob = old_sd.get("sensory.0.bias")
                            if ow is not None and ow.shape[1] == STATE_DIM:
                                rows = min(ow.shape[0], w.shape[0])
                                w[:rows].copy_(ow[:rows])
                                b[:rows].copy_(ob[:rows])
                        except Exception:
                            pass
                    self.target.load_state_dict(self.policy.state_dict())
                    log(f"migrated {ckpt.get('arch')} sensory weights into v3-MASSIVE brain, epsilon={self.epsilon:.2f}")
                else:
                    log(f"unknown checkpoint arch — starting fresh brain, epsilon={self.epsilon:.2f}")
            except Exception as e:
                log(f"model load note: {e}")
        if os.path.exists("ml_replay.json"):
            try:
                with open("ml_replay.json") as f:
                    data = json.load(f)
                for item in data:
                    if len(item) == 5:
                        item = list(item) + [1]
                    self.buffer.append(item)
                    r_val = float(item[2])
                    self.priorities.append(2.0 if abs(r_val) >= 1.0 else 1.0)
                log(f"restored {len(data)} prioritized replay memories from disk")
            except Exception as e:
                log(f"replay restore failed: {e}")


# ---------------------- Full-Vision State Builder ----------------------
def build_state(mlxir, lv, rv, phase, last_slot, last_spot,
                towers=None, arena=None, afford=None):
    """38-dim state vector populated with full vision:
      [0]     : elixir / 10
      [1..2]  : left & right lane pixel variance
      [3..6]  : reference card costs
      [7..10] : true pixel-sensed card slot affordability (4 slots)
      [11..13]: match phase one-hot (early, mid, late)
      [14..17]: last played card slot one-hot
      [18..22]: last played placement spot one-hot
      [23..27]: tower HP fractions (ally_left, ally_right, ally_king, enemy_left, enemy_right)
      [28..29]: tower count advantage (ally_alive/3, enemy_alive/3)
      [30..35]: active field unit vision (enemy_left, enemy_right, enemy_bridge_l,
                enemy_bridge_r, ally_left, ally_right)
      [36..37]: imminent threat flags (left_threat, right_threat)
    """
    state = [0.0] * STATE_DIM
    state[0] = mlxir / 10.0
    state[1] = min(lv / 100.0, 1.0)
    state[2] = min(rv / 100.0, 1.0)
    try:
        hand_deck = json.load(open(AUTONOMOUS_DECK_FILE)).get("deck") or ["musketeer", "knight", "archers", "giant"]
    except Exception:
        hand_deck = ["musketeer", "knight", "archers", "giant"]
    for i, name in enumerate(hand_deck[:4]):
        c = CARDS_DB.get((name or "").strip().lower(), {}).get("cost", 4)
        state[3 + i] = c / 10.0
        if afford is not None and i < len(afford):
            state[7 + i] = float(afford[i])
        else:
            state[7 + i] = 1.0 if c <= mlxir else 0.0
    state[11 + (phase % 3)] = 1.0
    state[14 + (last_slot % 4)] = 1.0
    state[18 + (last_spot % 5)] = 1.0

    if towers:
        state[23] = float(towers.get("ally_left", 1.0))
        state[24] = float(towers.get("ally_right", 1.0))
        state[25] = float(towers.get("ally_king", 1.0))
        state[26] = float(towers.get("enemy_left", 1.0))
        state[27] = float(towers.get("enemy_right", 1.0))
        state[28] = float(towers.get("ally_alive", 3)) / 3.0
        state[29] = float(towers.get("enemy_alive", 3)) / 3.0

    if arena:
        state[30] = min(arena.get("enemy_left", 0) / 40.0, 1.0)
        state[31] = min(arena.get("enemy_right", 0) / 40.0, 1.0)
        state[32] = min(arena.get("enemy_bridge_l", 0) / 20.0, 1.0)
        state[33] = min(arena.get("enemy_bridge_r", 0) / 20.0, 1.0)
        state[34] = min(arena.get("ally_left", 0) / 40.0, 1.0)
        state[35] = min(arena.get("ally_right", 0) / 40.0, 1.0)
        state[36] = 1.0 if arena.get("enemy_bridge_l", 0) >= 3 else 0.0
        state[37] = 1.0 if arena.get("enemy_bridge_r", 0) >= 3 else 0.0

    return state


def foreground_app():
    """Return 'clashroyale', 'other', 'unknown'
    (focused app present but not identifiable) or None (adb unreachable).
    Uses BOTH mCurrentFocus and mFocusedApp, and treats 'GameApp' windows of
    com.supercell.clashroyale as in-game even mid-activity transition."""
    try:
        focus = sh(["shell", "dumpsys", "window"], timeout=15)
        if focus.returncode != 0 and not focus.stdout:
            return None
        text = focus.stdout.decode(errors="ignore")
        line_focus = next((l for l in text.splitlines() if "mCurrentFocus" in l), "")
        line_app = next((l for l in text.splitlines() if "mFocusedApp" in l), "")
        merged = (line_focus + " " + line_app).lower()
        if "clashroyale" in merged or "com.supercell" in merged:
            return "clashroyale"
        if "notificationshade" in merged or "null" in merged:
            return "clashroyale_or_locked" if "NotificationShade" in (line_focus + line_app) else "unknown"
        if line_focus or line_app:
            return "other"
        return "unknown"
    except Exception:
        return None


AUTONOMOUS_DECK_FILE = "my_deck.json"


def _local_meta_deck(stats):
    """Deck-understanding fallback: pick the best 8-card meta deck from
    meta_decks.json matched to the agent's OWN memory (its recent winrate and
    what beat it), with anti-beatdown backup selection when it lost recently.
    Works with zero Groq — the agent can always build decks."""
    try:
        meta = json.load(open("meta_decks.json"))
        decks = meta.get("top_meta_decks") or []
    except Exception:
        decks = [{"cards": ["hogrider", "musketeer", "ice_golem", "cannon",
                            "skeletons", "minions", "fireball", "zap"],
                  "name": "builtin-fallback", "style": "cycle", "avg_elixir": 3.0}]
    # memory-aware pick: if losses recently outweight wins, prefer a CONTROL deck
    recent = (stats or {}).get("recent_winrate", 50.0)
    scored = []
    for d in decks:
        s = 1.0
        cards = [c.lower() for c in d.get("cards", [])]
        if len(cards) < 6:
            continue
        has_spell = any(c in ("fireball", "arrows", "zap", "poison") for c in cards)
        has_building = any(c in ("cannon", "tesla", "inferno_tower", "bomb_tower") for c in cards)
        if recent < 45.0:
            # losing → favor defense-included control decks
            s += 0.6 * (int(has_spell) + int(has_building)) / 2
        else:
            # winning → keep cycle pressure
            s += 0.4 if d.get("style") == "cycle" else 0.0
        s += 0.2 * int(sum(1 for c in cards if c in CARDS_DB) >= 6)
        scored.append((s, d))
    scored.sort(key=lambda x: x[0], reverse=True)
    if scored:
        return scored[0][1]
    return decks[0] if decks else None


def autonomous_deck_session(gm_stats=None):
    """Once per startup AND on every 5th match end: build the deck.

    Two builders cooperate:
      1. Groq Deck Architect (live meta awareness)
      2. Local meta matcher (always works, no key needed; picks from the real
         fetched meta list, memory-aware)
    NEVER touches in-game Deck Edit (ToS) — but the deck file that drives
    play policy is always freshly built either way.
    """
    try:
        player_deck = json.load(open(AUTONOMOUS_DECK_FILE)).get("deck")
    except Exception:
        player_deck = None
    chosen, critique, source = None, "", ""
    r = groq_deck_builder(player_deck)
    if r.get("deck") and len(r["deck"]) >= 6:
        chosen, critique, source = r["deck"][:8], r.get("critique", ""), "groq"
    else:
        d = _local_meta_deck(gm_stats)
        if d:
            chosen, critique, source = d["cards"][:8], d.get("name", "") + " (local meta match)", "local"
    if chosen and len(chosen) >= 6:
        try:
            json.dump({"deck": chosen, "critique": critique,
                       "built_by": source,
                       "updated": time.strftime("%Y-%m-%d %H:%M")},
                      open(AUTONOMOUS_DECK_FILE, "w"), indent=1)
            log(f"DECK ARCHITECT ({source}) built deck: {chosen} ({critique[:60]})")
        except Exception:
            pass
    else:
        log("deck architect could not build any deck (no meta + no groq) — keeping prior")
    return {"deck": chosen, "source": source}


def main():
    log("NeuroML v11 (Dueling DQN + full vision + Groq coach) started on " + DEV)
    offline_since = None
    brain = TargetedDQN()
    brain.load()
    try:
        autonomous_deck_session(game_memory_digest())  # deck built at every startup
    except Exception as e:
        log(f"deck session note: {e}")
    # Warm-train 3 steps on restored replay memories so new Dueling head aligns immediately
    if len(brain.buffer) >= brain.batch:
        for _ in range(3):
            brain.train_step()
        brain.save()
        log(f"warm-trained Dueling Double DQN on {len(brain.buffer)} memories")

    just_queued = False
    back_streak = 0
    popup_hits = 0
    stuck_since = None
    tick_in_match = 0
    prev_state = None
    prev_action = None
    prev_towers = None
    elixir_leak_ticks = 0
    last_spell_played = None
    _finisher_cast = False
    train_loss_ma = None
    cards_played = 0
    mentor_cooldown = 0.0
    opp_memory_store = _load_opponent_memory()
    game_memory = _load_game_memory()
    match_stats = {"reward_total": 0.0, "ticks": 0, "cards_played": 0,
                   "pushes_faced": 0, "towers_down": 0, "towers_lost": 0,
                   "rule_corrections": 0, "spot_totals": {}}
    opponent = None
    opponent_arena_prev = None
    opponent_towers_prev = None
    last_fg_note = 0.0
    user_saw_clash = None
    pain_channels = _load_pain_channels()
    brain_ref[0] = brain

    while True:
        try:
            # ---- GATE: no sensing, no tapping, no learning unless the game
            # is the foreground app AND the phone is reachable ----
            fg = foreground_app()
            if fg is None:
                offline_since = offline_since or time.time()
                if time.time() - offline_since > 10:
                    log("phone unreachable (left Wi-Fi?) — waiting for reconnect")
                    sh(["connect", DEV], timeout=20)
                time.sleep(10)
                continue
            offline_since = None
            if fg != "clashroyale":
                # USER-CONTROLLED PLAY: only ever act when the user has Clash
                # open themselves. Never wake the phone, never unlock, never
                # launch the game from another app. Wait politely, check again.
                if fg != user_saw_clash and time.time() - (last_fg_note or 0) > 600:
                    log(f"waiting for user to open Clash (currently fg={fg}) — bot only plays when YOU open the game")
                    last_fg_note = time.time()
                user_saw_clash = fg
                time.sleep(5)
                continue

            # ---- gate passed: USER opened Clash — play ----
            png = screenshot()
            from PIL import Image
            img = Image.open(png).convert("RGB")
            state = classify(img)
            if state == "unknown":
                g_state = groq_vision_classify(img)
                if g_state in ("battle", "lobby", "result", "quit_dialog", "popup"):
                    state = g_state

            now = time.time()
            if stuck_since and now - stuck_since > 45:  # was 90s — UI recovery must be snappy
                log(f"stuck on '{state}' for 45s — force cycle (OK → BACK → Battle tab)")
                brain.save()
                taps = [OK_CENTER, RESULT_OK, CANCEL_BUTTON, BATTLE_BUTTON]
                for t in taps:
                    tap(*t)
                    time.sleep(0.5)
                # NOTE: never force-stop/relaunch the game on stuck — that would
                # break the user's rule of only playing when THEY open Clash.
                # The tap cycle above is enough; we just keep waiting.
                stuck_since = None
                back_streak = 0
                popup_hits = 0
                just_queued = False
                continue

            if state == "quit_dialog":
                log("quit dialog -> Cancel")
                tap(*CANCEL_BUTTON)
                back_streak = 0
                stuck_since = stuck_since or now
                continue

            if state == "battle":
                stuck_since = None
                back_streak = 0
                just_queued = False
                if opponent is None:
                    opponent = opponent_new_match()
                    match_stats = {"reward_total": 0.0, "ticks": 0, "cards_played": 0,
                                   "pushes_faced": 0, "towers_down": 0, "towers_lost": 0,
                                   "rule_corrections": 0, "spot_totals": {}}
                    log("new opponent tracked (memory persistent across matches)")
                mlxir = elixir_count(img)
                lv, rv = lane_variances(img)
                towers = tower_healths(img)
                arena = scan_arena_vision(img)
                afford = hand_affordability(img, mlxir)

                if arena["enemy_left"] > arena["enemy_right"] + 4 or arena["enemy_bridge_l"] >= 3:
                    lane = "left"
                elif arena["enemy_right"] > arena["enemy_left"] + 4 or arena["enemy_bridge_r"] >= 3:
                    lane = "right"
                else:
                    lane = "left" if lv > rv * 1.3 and lv > 30 else ("right" if rv > lv * 1.3 and rv > 30 else None)

                phase = match_phase(img, tick_in_match)
                leaking = mlxir >= 10
                state_s = build_state(
                    mlxir, lv, rv, phase,
                    prev_action // 5 if prev_action is not None else 0,
                    prev_action % 5 if prev_action is not None else 0,
                    towers=towers, arena=arena, afford=afford,
                )

                affordable_slots = [i for i in range(4) if state_s[7 + i] > 0.5]
                forbidden = set()
                for slot in range(4):
                    if slot not in affordable_slots:
                        for spot in range(5):
                            forbidden.add(slot * 5 + spot)

                action = brain.act(state_s, forbidden=forbidden)
                slot, spot_i = divmod(action, 5)
                spot_n = SPOT_NAMES[spot_i]
                mentor = None

                # ---- GAME-KNOWLEDGE REFEREE (rules on top of the network) ----
                hand_deck = []
                try:
                    hand_deck = json.load(open(AUTONOMOUS_DECK_FILE)).get("deck") or []
                except Exception:
                    pass
                finishers = tower_finish_check(towers, hand_deck, mlxir)
                action, rule_note = card_play_policy(
                    action, mlxir, lane, arena, towers, afford, hand_deck, finishers)
                slot, spot_i = divmod(action, 5)
                spot_n = SPOT_NAMES[spot_i]
                if rule_note != "net":
                    reward_rules_add = 0.35  # following learned game rules is smart play
                    match_stats["rule_corrections"] += 1
                    log(f"RULES: {rule_note} slot={slot} spot={spot_n}")
                else:
                    reward_rules_add = 0.0
                # game memory: accumulate per-spot dopamine totals
                _st = match_stats["spot_totals"].setdefault(spot_n, [0.0, 0])
                match_stats["spot_totals"][spot_n] = [round(_st[0], 3), _st[1] + 1]

                # ---- Compute Dopamine / Punishment Signal ----
                reward = 0.0
                dmg_punish = None
                dmg_source = None
                _events = []  # every labeled dopamine/punishment event this tick

                # ---- SPELL VALUE TRACKING: did the spell cast ONE tick ago hit
                # anything? (enemy units present, or enemy tower HP dropped)
                # Hitting nothing = WASTED SPELL = heavy punishment. ----
                if last_spell_played is not None and opponent_arena_prev is not None and prev_towers is not None:
                    _slot_i, _spot_i = last_spell_played
                    _spell_name = ""
                    try:
                        _deck_now = json.load(open(AUTONOMOUS_DECK_FILE)).get("deck") or []
                        _spell_name = _deck_now[_slot_i] if _slot_i < len(_deck_now) else ""
                    except Exception:
                        pass
                    _role = CARDS_DB.get(str(_spell_name).lower(), {}).get("role")
                    if _role == "spell":
                        _hit_units = (opponent_arena_prev.get("enemy_left", 0) +
                                      opponent_arena_prev.get("enemy_right", 0)) >= 1
                        _el_tower_drop = max(0.0, prev_towers.get("enemy_left", 1) - towers.get("enemy_left", 1))
                        _er_tower_drop = max(0.0, prev_towers.get("enemy_right", 1) - towers.get("enemy_right", 1))
                        _hit_tower = (_el_tower_drop + _er_tower_drop) >= 0.03
                        if _hit_units or _hit_tower or _finisher_cast:
                            _v = "damaged units" if _hit_units else ("chipped enemy tower" if _hit_tower else "finisher attempt")
                            _bonus = 0.3
                            reward += _bonus
                            _events.append((f"✨ spell connected: {_v}", _bonus))
                            log(f"SPELL VALUE: {_spell_name} {_v} -> +{_bonus:.2f}")
                        else:
                            _punish = -1.2
                            record_pain(pain_channels, _slot_i, _spot_i, _punish)
                            _save_pain_channels(pain_channels)
                            reward += _punish
                            _events.append((f"🚫 WASTED SPELL {_spell_name} — hit nothing", _punish))
                            log(f"SPELL WASTED: {_spell_name} hit nothing -> {_punish:+.2f}")
                _finisher_cast = False
                last_spell_played = None

                if prev_towers is not None:
                    dl = max(0.0, prev_towers["ally_left"] - towers["ally_left"])
                    dr = max(0.0, prev_towers["ally_right"] - towers["ally_right"])
                    dk = max(0.0, prev_towers["ally_king"] - towers["ally_king"])
                    ally_drop = dl + dr + dk
                    ally_lost = max(0, prev_towers["ally_alive"] - towers["ally_alive"])

                    if ally_drop >= 0.05 or ally_lost > 0:
                        dmg_info = {
                            "ally_hp_drop": ally_drop,
                            "ally_towers_lost": ally_lost,
                            "ally_left": towers["ally_left"],
                            "ally_right": towers["ally_right"],
                            "ally_king": towers["ally_king"],
                        }
                        dmg_punish, dmg_source = groq_damage_punishment(dmg_info, img)
                        reward += dmg_punish
                        match_stats["towers_lost"] += int(ally_lost)
                        log(
                            f"TOWER DAMAGE TAKEN (drop={ally_drop:.2f}, lost={ally_lost}) "
                            f"-> punishment={dmg_punish:+.2f} via {dmg_source}"
                        )
                        # loss is real even before shaping — tag it for the feed

                    el_drop = max(0.0, prev_towers["enemy_left"] - towers["enemy_left"])
                    er_drop = max(0.0, prev_towers["enemy_right"] - towers["enemy_right"])
                    enemy_drop = el_drop + er_drop
                    enemy_lost = max(0, prev_towers["enemy_alive"] - towers["enemy_alive"])
                    if dmg_punish is None and (enemy_drop >= 0.05 or enemy_lost > 0):
                        enemy_bonus = min(2.0, round(enemy_drop * 2.5 + enemy_lost * 1.2, 2))
                        reward += enemy_bonus
                        match_stats["towers_down"] += int(enemy_lost)
                        log(f"ENEMY TOWER DAMAGED (drop={enemy_drop:.2f}) -> dopamine +{enemy_bonus:.2f}")

                # ---- RICH DOPAMINE SHAPING (each item logged as its OWN
                # dopamine event so the feed never shows a bad behavior green) ----
                # (_events was created above for spell tracking — reuse it)
                if dmg_punish is None:
                    # 1) correct-lane defense
                    if lane:
                        if (lane == "left" and spot_n in ("left_defend", "bridge_left")) or \
                           (lane == "right" and spot_n in ("right_defend", "bridge_right")):
                            reward += 0.8
                            _events.append(("✅ correct lane defense", 0.8))
                    # 2) spend at max elixir
                    if mlxir >= 10 and "center_back" not in spot_n and "bridge" in spot_n:
                        reward += 0.4
                        _events.append(("✅ spent at max elixir", 0.4))
                    # 3) elixir discipline: playing at 9-10 elixir is good economy
                    if mlxir >= 9:
                        reward += 0.25
                        _events.append(("✅ elixir economy (played at 9+)", 0.25))
                    # 4) proactive counter-push: attacking the opposite lane when enemy commits
                    if arena["enemy_left"] + arena["enemy_right"] >= 8 and "bridge" in spot_n:
                        opposite = arena["enemy_right"] if arena["enemy_left"] >= arena["enemy_right"] else arena["enemy_left"]
                        if opposite <= 2:
                            reward += 0.6
                            _events.append(("✅ counter-push other lane", 0.6))
                    # 5) counter-threshold rewards (visible dopamine when ahead)
                    if towers["enemy_alive"] < towers["ally_alive"]:
                        reward += 0.3
                        _events.append(("✅ tower advantage held", 0.3))
                    # 6) RULES dopamine: playing by the law of the game is rewarded
                    if reward_rules_add:
                        reward += reward_rules_add
                        _events.append(("✅ game rule followed", reward_rules_add))
                    # 7) TROOP-KILL DOPAMINE: vision sees enemy units die
                    e_units_prev = (opponent_arena_prev.get("enemy_left", 0) +
                                    opponent_arena_prev.get("enemy_right", 0)) if opponent_arena_prev else 0
                    e_units_now = arena["enemy_left"] + arena["enemy_right"]
                    e_death = max(0, e_units_prev - e_units_now)
                    if e_death >= 4:
                        kill_dopamine = min(1.5, round(e_death * 0.1, 2))
                        reward += kill_dopamine
                        _events.append((f"💀 killed {e_death}px of enemy troops", kill_dopamine))
                        log(f"ENEMY TROOPS KILLED ({e_death}px bars fell) -> dopamine +{kill_dopamine:.2f}")
                else:
                    reward = min(reward, dmg_punish)
                    _events.append(("🛑 my tower took damage", dmg_punish))
                    _events.append(("⛔ good events censored — tower damage dominates this tick", 0.0))
                    # SYNAPTIC PAIN: this (slot,spot) channel gets an LTD tag —
                    # repeating the same play will hurt more and be avoided sooner.
                    record_pain(pain_channels, slot, spot_i, dmg_punish)
                    _save_pain_channels(pain_channels)

                # ---- PUNISHMENTS (always their OWN negative event, never green) ----
                # CYCLING AMNESTY: leaking while deliberately cycling cheap cards
                # (hand full of affordable low-costs, no big threat) is GOOD
                # resource conversion, not waste — no punishment then.
                cheap_in_hand = sum(1 for i in range(4) if state_s[7 + i] > 0.5) >= 2
                cycling_ok = leaking and cheap_in_hand and not lane
                if mlxir <= 2 and lane is None:
                    reward -= 0.2
                    _events.append(("🔻 wasted elixir nowhere (played with no threat)", -0.2))
                if leaking and not cycling_ok:
                    elixir_leak_ticks += 1
                    leak_punish = 0.1 * elixir_leak_ticks
                    reward -= leak_punish
                    _events.append((f"💧 ELIXIR LEAK #{elixir_leak_ticks}", -leak_punish))
                elif leaking and cycling_ok:
                    elixir_leak_ticks = 0
                    _events.append(("♻️ cycling cheap cards at max elixir (allowed)", 0.15))
                else:
                    elixir_leak_ticks = 0
                # dropped tower this tick = pure red event even if kills happened
                if prev_towers is not None:
                    _tl = max(0, prev_towers["ally_alive"] - towers["ally_alive"])
                    if _tl > 0:
                        _events.append((f"💀 LOST {_tl} TOWER(S)", -2.5 * _tl))
                # incorrect lane defense = red
                if lane and dmg_punish is None:
                    if (lane == "left" and spot_n in ("right_defend", "bridge_right")) or \
                       (lane == "right" and spot_n in ("left_defend", "bridge_left")):
                        reward -= 0.6
                        _events.append(("❌ defended the WRONG lane", -0.6))

                # Humanized swipe: tiny jitter on start point + variable duration
                jx = random.randint(-SWIPE_START_JITTER, SWIPE_START_JITTER)
                jy = random.randint(-SWIPE_START_JITTER, SWIPE_START_JITTER)
                dur = random.randint(280, 420)
                x, y = CARDS[slot % 4]
                sx, sy = FIELD_SPOTS[spot_n]
                sh(["shell", "input", "swipe", str(x + jx), str(y + jy), str(sx), str(sy), str(dur)])
                time.sleep(0.45)
                # Track spell casts for next-tick value judgment (hit vs wasted)
                _played_name = ""
                try:
                    _deck_now = json.load(open(AUTONOMOUS_DECK_FILE)).get("deck") or []
                    _played_name = _deck_now[slot] if slot < len(_deck_now) else ""
                except Exception:
                    pass
                if CARDS_DB.get(str(_played_name).lower(), {}).get("role") == "spell":
                    last_spell_played = (slot, spot_i)
                    _finisher_cast = bool(finishers) and rule_note.startswith("finisher")
                cards_played += 1
                tick_in_match += 1
                # game-memory accumulators
                match_stats["reward_total"] += reward
                match_stats["ticks"] += 1
                match_stats["cards_played"] += 1
                match_stats["pushes_faced"] = len(opponent["pushes"]) if opponent else match_stats["pushes_faced"]
                match_stats["towers_down"] = match_stats["towers_down"]
                screenshot_async()  # pipeline: next frame encodes while we think/train
                log(
                    f"elixir={mlxir} lane={lane} towers_hp=({towers['ally_left']:.2f},{towers['ally_right']:.2f},{towers['ally_king']:.2f}) "
                    f"enemy_hp=({towers['enemy_left']:.2f},{towers['enemy_right']:.2f}) "
                    f"units=(E:{arena['enemy_left']}/{arena['enemy_right']} A:{arena['ally_left']}/{arena['ally_right']}) "
                    f"slot={slot} spot={spot_n} reward={reward:+.2f} eps={brain.epsilon:.2f} "
                    f"loss={f'{train_loss_ma:.4f}' if train_loss_ma else 'n/a'}"
                )
                _metrics["epsilon"] = brain.epsilon
                _metrics["neurons"] = brain.dopamine_report(state_s)
                # Real-time ML equations panel (what the model is literally computing)
                with torch.no_grad():
                    x_t = torch.tensor(state_s, dtype=torch.float32)
                    q_row = brain.policy(x_t)
                    top = torch.topk(q_row, 3)
                    if prev_state is not None:
                        s2_t = torch.tensor(prev_state, dtype=torch.float32)
                        na = torch.argmax(q_row)
                        td_est = reward + brain.gamma * brain.target(s2_t).max().item() - q_row.max().item()
                    else:
                        td_est = reward
                    _metrics["thinking"] = {
                        "q_values_top3": [(int(i), round(v.item(), 3)) for v, i in zip(top.values, top.indices)],
                        "chosen_action": action,
                        "chosen_q": round(q_row[action].item(), 3),
                        "td_error_recent": round(td_est, 3),
                        "gamma": brain.gamma,
                        "per_beta": round(brain.per_beta, 3),
                        "equation": (
                            f"Q(s,a) = V(s) + A(s,a) - mean(A) ; "
                            f"target = r {reward:+.2f} + γ·maxQ(s',a*) γ={brain.gamma} ; "
                            f"TD={td_est:+.3f}"
                        ),
                        "hud": (
                            f"loss_ma={f'{train_loss_ma:.4f}' if train_loss_ma else 'n/a'} "
                            f"buffer={len(brain.buffer)} eps={brain.epsilon:.3f}"
                        ),
                    }
                vision_snapshot = {
                    "towers": towers,
                    "arena_units": arena,
                    "affordable_slots": affordable_slots,
                    "elixir": mlxir,
                }
                # Dopamine events — every labeled signal, good AND bad, shown
                # separately so the feed never turns bad into green.
                # Pain channels are shown as their own red channel-level rows so
                # LTD is VISIBLE, not hidden.
                _dlog = _metrics.setdefault("dopamine_events", [])
                for lbl, amt in _events:
                    _dlog.append({"t": time.strftime("%H:%M:%S"),
                                  "event": f"{lbl} · {spot_n} (elixir {mlxir})",
                                  "amount": round(amt, 2)})
                _p = pain_channels.get((slot, spot_i))
                if _p is not None and _p < -0.6:
                    _dlog.append({"t": time.strftime("%H:%M:%S"),
                                  "event": f"🔥 pain channel {slot},{spot_n} avg {_p:+.2f} (LTD active)",
                                  "amount": 0.0})
                _metrics["dopamine_events"] = _dlog[-80:]
                _metrics["pain_channels_top"] = [
                    {"slot": k[0], "spot": SPOT_NAMES[k[1]] if k[1] < 5 else k[1], "avg": round(v, 2)}
                    for k, v in sorted(pain_channels.items(), key=lambda x: x[1])[:6]
                ]
                metrics_append(None, reward=reward, action=action, dmg_punish=dmg_punish,
                               vision=vision_snapshot,
                               mentor=(None if mentor is None else {
                                   "critique": mentor.get("critique"),
                                   "reward_delta": mentor.get("reward_delta"),
                                   "recommended_spot": mentor.get("recommended_spot"),
                               }))

                if prev_state is not None and prev_action is not None:
                    brain.remember(prev_state, prev_action, reward, state_s, done=False)
                    # HIPPOCAMPAL ARCHIVE: every rich transition stored forever
                    hippocampal_write({
                        "t": time.time(), "s": prev_state, "a": prev_action,
                        "r": round(reward, 3), "s2": state_s, "done": False,
                        "elixir": mlxir, "lane": lane, "spot": spot_n,
                        "towers": towers, "arena": arena,
                        "pain_avg": pain_channels.get((slot, spot_i)),
                    })
                    # Consolidation: stir in 8 random old memories occasionally
                    if tick_in_match % 30 == 0 and len(brain.buffer) >= brain.batch:
                        for _mem in hippocampal_sample(8):
                            try:
                                brain._push_per([_mem["s"], int(_mem["a"]), float(_mem["r"]),
                                                 _mem.get("s2", _mem["s"]), bool(_mem.get("done")), 1],
                                                init_prio=1.2)
                            except Exception:
                                pass
                    if mentor is not None and mentor.get("recommended_spot") is not None:
                        rec_action = (prev_action // 5) * 5 + SPOT_TO_ACTION[mentor["recommended_spot"]]
                        brain._push_per([prev_state, rec_action, 0.6, state_s, False, 1],
                                        init_prio=1.5)  # mentor imitation memory

                if brain.buffer and len(brain.buffer) >= brain.batch and tick_in_match % brain.train_every == 0:
                    loss = brain.train_step()
                    if loss is not None:
                        train_loss_ma = loss if train_loss_ma is None else train_loss_ma * 0.9 + loss * 0.1
                    if tick_in_match % 24 == 0:
                        brain.save()
                        log(f"checkpoint saved: buffer={len(brain.buffer)} loss={train_loss_ma:.4f}")

                # ---- AI Coach (Punisher + Mentor) reviews every move ----
                mentor = None
                if not leaking and time.time() >= mentor_cooldown:
                    mentor_cooldown = time.time() + 22  # stay under free-tier rate limit
                    _desperate = towers["ally_king"] <= 0.35
                    _low_t = min(towers["enemy_left"], towers["enemy_right"])
                    state_desc = (
                        f"elixir={mlxir}, lane_threat={lane}, "
                        f"enemy_units(E:{arena['enemy_left']}/{arena['enemy_right']}, "
                        f"bridges {arena['enemy_bridge_l']}/{arena['enemy_bridge_r']}), "
                        f"air_threat={arena.get('air_threat', 0)}, "
                        f"tower_hp(me {towers['ally_left']:.1f}/{towers['ally_right']:.1f}/{towers['ally_king']:.1f}, "
                        f"enemy {towers['enemy_left']:.1f}/{towers['enemy_right']:.1f}), "
                        f"DESPERATION={'YES' if _desperate else 'no'}, "
                        f"weakest_enemy_tower={'L' if towers['enemy_left'] <= towers['enemy_right'] else 'R'}(HP {_low_t:.2f}), "
                        f"hand_deck={hand_deck}, affordable_slots={affordable_slots}, phase={phase}, "
                        f"recent_creeps={len(opp_memory_store.get('recent_opponents', []))}"
                    )
                    mentor = groq_reward_governor(state_desc, spot_n, reward, img)
                    if mentor["source"] == "groq_oss_coach":
                        # PUNISHER: blend coach verdict into dopamine signal
                        if mentor["reward_delta"] is not None:
                            reward += mentor["reward_delta"]
                            log(f"COACH review: {mentor['critique']} (reward_delta={mentor['reward_delta']:+.2f})")
                        mentor_entry = {
                            "played": spot_n, "critique": mentor.get("critique"),
                            "reward_delta": mentor.get("reward_delta"),
                            "recommended_spot": mentor.get("recommended_spot"),
                            "agree": mentor.get("agree"),
                        }
                        mentor_log_line(mentor_entry)
                        _metrics["mentor_agree"] = _metrics.get("mentor_agree", 0)
                        # MENTOR: remember the coach's recommended action for this state
                        if mentor["recommended_spot"] is not None:
                            rec_action = slot * 5 + SPOT_TO_ACTION[mentor["recommended_spot"]]
                            brain._push_per([state_s, rec_action, 0.6, state_s, False, 1], init_prio=1.5)
                            _metrics["mentor_actions"] = _metrics.get("mentor_actions", {})
                            _metrics["mentor_actions"][mentor["recommended_spot"]] = \
                                _metrics["mentor_actions"].get(mentor["recommended_spot"], 0) + 1

                # ---- OPPONENT MEMORY: observe their pushes and troop waves ----
                opponent_observe(
                    opponent, opponent_arena_prev, arena, opponent_towers_prev, towers)
                opponent_arena_prev = arena
                opponent_towers_prev = towers
                opponent_arena_prev = arena
                opponent_towers_prev = towers

                prev_state = state_s
                prev_action = action
                prev_towers = towers
                time.sleep(TICK_SECONDS)

            elif state == "lobby":
                stuck_since = None
                back_streak = 0
                prev_towers = None
                if prev_state is not None and prev_action is not None:
                    brain.remember(prev_state, prev_action, 0.0, prev_state, done=True)
                    prev_state = None
                    prev_action = None
                    brain.epsilon = max(0.05, brain.epsilon * 0.985)
                    brain.save()
                    log(f"match memory flushed: buffer={len(brain.buffer)} eps={brain.epsilon:.3f}")
                if not just_queued:
                    log("lobby -> claim + battle")
                    tap(*CLAIM_SPOT)
                    time.sleep(1.5)
                    tap(*BATTLE_BUTTON)
                    just_queued = True
                    tick_in_match = 0
                    time.sleep(6)
                else:
                    time.sleep(6)

            elif state == "result":
                stuck_since = stuck_since or now
                prev_towers = None
                from PIL import Image as _I
                _img = _I.open(png).convert("RGB")
                _verdict = judge_match_result(_img)
                dopamine = 4.0 if _verdict == "WIN" else -4.5
                # ---- DOPAMINE EVENT STREAM (the UI's live dopamine feed) ----
                _dlog = _metrics.setdefault("dopamine_events", [])
                _dlog.append({"t": time.strftime("%H:%M:%S"), "event": f"MATCH {_verdict}", "amount": dopamine})
                _metrics["dopamine_events"] = _dlog[-80:]
                # ---- OPPONENT MEMORY: persist this opponent's habits ----
                if opponent is not None:
                    opp_memory_store.setdefault("recent_opponents", []).insert(0, {
                        "when": time.strftime("%m-%d %H:%M"),
                        "result": _verdict,
                        "cards_seen": len(opponent.get("cards_played", [])),
                        "pushes": opponent.get("pushes", [])[-8:],
                    })
                    opp_memory_store["recent_opponents"] = opp_memory_store["recent_opponents"][:30]
                    _save_opponent_memory(opp_memory_store)
                    _metrics["opponent_memory"] = {
                        "known": len(opp_memory_store.get("recent_opponents", [])),
                        "this_match_pushes": len(opponent.get("pushes", [])),
                    }
                    opponent = None
                log(f"result screen ({_verdict}) -> dopamine {dopamine:+.1f}")
                if prev_state is not None and prev_action is not None:
                    brain.remember(prev_state, prev_action, dopamine, prev_state, done=True)
                    brain.train_step()  # learn from the final episode transition NOW
                    prev_state = None
                    prev_action = None
                    brain.epsilon = max(0.05, brain.epsilon * 0.985)
                # W/L counters (authoritative signal the user asked for).
                # NOTE: ml_metrics.json's "losses" key is NOT this counter — it also
                # carries the training-loss history list. So store W/L under
                # wins_v/losses_v explicitly to never collide.
                if _verdict == "WIN":
                    _metrics["wins_v"] = int(_metrics.get("wins_v", 0) or 0) + 1
                else:
                    _metrics["losses_v"] = int(_metrics.get("losses_v", 0) or 0) + 1
                _metrics["win_history"] = (_metrics.get("win_history") or [])[-60:] + [1 if _verdict == "WIN" else 0]
                w_, l_ = int(_metrics.get("wins_v", 0)), int(_metrics.get("losses_v", 0))
                wr = round(100.0 * w_ / max(1, w_ + l_), 1)
                _metrics["win_rate"] = wr
                # ---- GAME MEMORY: distill this match into the long-term book ----
                match_stats["reward_total"] += dopamine
                dig = distill_match(_verdict, match_stats)
                _metrics["game_memory"] = dig
                log(f"GAME MEMORY distilled: {dig.get('one_line', '')}")
                # Episode-final hippocampal write with the verdict dopamine
                hippocampal_write({"t": time.time(), "episode_end": _verdict,
                                   "dopamine": dopamine,
                                   "stats": {"ticks": match_stats["ticks"],
                                             "towers_down": match_stats["towers_down"],
                                             "towers_lost": match_stats["towers_lost"]}})
                # Re-evaluate deck every 5th match — adaptation built in
                _matches_seen = int(_metrics.get("matches", 0) or 0) + 1
                _metrics["matches"] = _matches_seen
                if _matches_seen % 5 == 0:
                    try:
                        autonomous_deck_session(dig)
                        log("deck re-evaluated from game memory (every 5 matches)")
                    except Exception as e:
                        log(f"deck re-eval note: {e}")
                brain.save()
                log(f"score now W{w_}/L{l_} winrate={wr}% eps={brain.epsilon:.3f} buffer={len(brain.buffer)}")
                tap(*OK_CENTER)
                time.sleep(2)
                # ---- PLAY AGAIN: classify what the game ACTUALLY shows after OK
                # and keep re-checking through transitions instead of standing
                # down on the first unclear frame:
                #   result  -> more dialogs; keep dismissing and re-check
                #   lobby   -> classic post-match lobby: press Battle again
                #   unknown -> transient transition; wait 3s and look again
                #   battle  -> matchmaking loading: hands off, loop takes over
                #   unknown -> transition; wait 3s and look again
                _pa_t0 = time.time()
                while time.time() - _pa_t0 < 20:
                    _re = sh(["exec-out", "screencap", "-p"], timeout=15)
                    if _re.returncode != 0 or not _re.stdout:
                        break
                    try:
                        _rimg = _I.open(io.BytesIO(_re.stdout)).convert("RGB")
                        nxt = classify(_rimg)
                    except Exception:
                        break
                    if nxt == "result":
                        tap(*OK_CENTER)
                        time.sleep(2)
                        continue
                    if nxt == "lobby":
                        just_queued = False
                        tap(*BATTLE_BUTTON)
                        just_queued = True
                        tick_in_match = 0
                        log("play again: Battle pressed from post-match lobby")
                        break
                    if nxt == "battle":
                        # matchmaking started on its own — just wait for it to resolve
                        log("play again: matchmaking already loading — hands off")
                        break
                    # unknown/popup: transition — wait a beat and look again
                    time.sleep(3)
                else:
                    pass

            elif state == "popup":
                stuck_since = stuck_since or now
                popup_hits += 1
                # Most popups dismiss with OK; some (chest opens) need OK then BACK
                log(f"popup -> dismiss (hit {popup_hits})")
                tap(*OK_CENTER)
                time.sleep(1.0)
                if popup_hits % 2 == 0:
                    sh(["shell", "input", "keyevent", "KEYCODE_BACK"])
                    time.sleep(1.2)

            elif state == "other_tab":
                stuck_since = None
                back_streak = 0
                prev_towers = None
                popup_hits = 0  # reset when we reach a lobby tab
                if prev_state is not None and prev_action is not None:
                    brain.remember(prev_state, prev_action, 0.0, prev_state, done=True)
                    prev_state = None
                    prev_action = None
                    brain.epsilon = max(0.05, brain.epsilon * 0.985)
                    brain.save()
                    log(f"match memory flushed: buffer={len(brain.buffer)} eps={brain.epsilon:.3f}")
                log("other lobby tab -> Battle tab")
                tap(*TOP_BATTLE_TAB)
                time.sleep(2.0)
                tap(*BATTLE_BUTTON)
                just_queued = True
                tick_in_match = 0
                time.sleep(6)

            else:  # truly unknown: probe with one BACK then OK, never blind-loop
                stuck_since = stuck_since or now
                focus = sh(["shell", "dumpsys", "window"], timeout=20)
                focus_text = focus.stdout.decode(errors="ignore")
                if "clashroyale" not in focus_text.lower():
                    # USER RULE: never launch the game ourselves — if the user
                    # left Clash, stop touching and wait for them to return.
                    log("game lost focus — waiting for user to reopen Clash")
                    stuck_since = None
                    time.sleep(5)
                    continue
                # FULL CLICK ACCESS: the bot may press any in-game control it needs
                # (BACK, OK, Battle, chest buttons…). The old "only 2 BACKs" cap is
                # intentionally lifted because safety lives in the user-gate above
                # (never acts unless the USER opened Clash) and the unknown-screen
                # detection — not in a BACK counter that stranded games.
                log(f"unknown -> BACK ({back_streak + 1}/unlimited)")
                sh(["shell", "input", "keyevent", "KEYCODE_BACK"])
                back_streak += 1
                if back_streak % 3 == 0:
                    log("unknown -> OK center probe (periodic)")
                    tap(*OK_CENTER)
                    time.sleep(2.5)
        except Exception as e:
            import traceback
            log(f"loop error: {type(e).__name__}: {e!r} {traceback.format_exc(limit=2)}")
            try:
                brain.save()
            except Exception:
                pass
            time.sleep(5)


def run_forever():
    """Entry point with a watchdog that restarts main() on repeated crashes."""
    while True:
        try:
            main()
        except Exception as e:
            log(f"watchdog caught: {type(e).__name__}: {e!r} — restarting in 10s")
            time.sleep(10)


if __name__ == "__main__":
    import sys
    if "--build-deck" in sys.argv:
        roles = {}
        for name, info in CARDS_DB.items():
            roles.setdefault(info["role"], []).append(name)
        deck = []
        for role, count in ("win_condition", 1), ("tank", 1), ("support", 3), ("spell", 2), ("building", 1):
            pool = roles.get(role, [])
            deck.extend(pool[:count])
        print(json.dumps(deck[:8], indent=2))
    else:
        run_forever()
